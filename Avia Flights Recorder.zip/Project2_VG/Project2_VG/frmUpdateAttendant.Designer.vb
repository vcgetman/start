﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmUpdateAttendant
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cboUpdate = New System.Windows.Forms.ComboBox()
        Me.lbl10 = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnSubmit = New System.Windows.Forms.Button()
        Me.gpbUpdate = New System.Windows.Forms.GroupBox()
        Me.txtDateHire = New System.Windows.Forms.TextBox()
        Me.lbl6 = New System.Windows.Forms.Label()
        Me.lbl4 = New System.Windows.Forms.Label()
        Me.lbl3 = New System.Windows.Forms.Label()
        Me.lbl2 = New System.Windows.Forms.Label()
        Me.lbl1 = New System.Windows.Forms.Label()
        Me.txtDateTerm = New System.Windows.Forms.TextBox()
        Me.txtEmployeeID = New System.Windows.Forms.TextBox()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.gpbUpdate.SuspendLayout()
        Me.SuspendLayout()
        '
        'cboUpdate
        '
        Me.cboUpdate.FormattingEnabled = True
        Me.cboUpdate.Location = New System.Drawing.Point(221, 45)
        Me.cboUpdate.Margin = New System.Windows.Forms.Padding(1)
        Me.cboUpdate.Name = "cboUpdate"
        Me.cboUpdate.Size = New System.Drawing.Size(246, 21)
        Me.cboUpdate.TabIndex = 39
        '
        'lbl10
        '
        Me.lbl10.AutoSize = True
        Me.lbl10.Location = New System.Drawing.Point(57, 45)
        Me.lbl10.Name = "lbl10"
        Me.lbl10.Size = New System.Drawing.Size(139, 13)
        Me.lbl10.TabIndex = 38
        Me.lbl10.Text = "Select Attendant to Update:"
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(250, 393)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(1)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(112, 32)
        Me.btnExit.TabIndex = 37
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'btnSubmit
        '
        Me.btnSubmit.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnSubmit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnSubmit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSubmit.Location = New System.Drawing.Point(91, 393)
        Me.btnSubmit.Margin = New System.Windows.Forms.Padding(1)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(112, 32)
        Me.btnSubmit.TabIndex = 36
        Me.btnSubmit.Text = "Submit"
        Me.btnSubmit.UseVisualStyleBackColor = False
        '
        'gpbUpdate
        '
        Me.gpbUpdate.Controls.Add(Me.txtDateHire)
        Me.gpbUpdate.Controls.Add(Me.lbl6)
        Me.gpbUpdate.Controls.Add(Me.lbl4)
        Me.gpbUpdate.Controls.Add(Me.lbl3)
        Me.gpbUpdate.Controls.Add(Me.lbl2)
        Me.gpbUpdate.Controls.Add(Me.lbl1)
        Me.gpbUpdate.Controls.Add(Me.txtDateTerm)
        Me.gpbUpdate.Controls.Add(Me.txtEmployeeID)
        Me.gpbUpdate.Controls.Add(Me.txtLastName)
        Me.gpbUpdate.Controls.Add(Me.txtFirstName)
        Me.gpbUpdate.Location = New System.Drawing.Point(91, 92)
        Me.gpbUpdate.Margin = New System.Windows.Forms.Padding(1)
        Me.gpbUpdate.Name = "gpbUpdate"
        Me.gpbUpdate.Padding = New System.Windows.Forms.Padding(1)
        Me.gpbUpdate.Size = New System.Drawing.Size(287, 268)
        Me.gpbUpdate.TabIndex = 35
        Me.gpbUpdate.TabStop = False
        Me.gpbUpdate.Text = "Update Attendant Info"
        '
        'txtDateHire
        '
        Me.txtDateHire.Location = New System.Drawing.Point(137, 157)
        Me.txtDateHire.Name = "txtDateHire"
        Me.txtDateHire.Size = New System.Drawing.Size(100, 20)
        Me.txtDateHire.TabIndex = 36
        '
        'lbl6
        '
        Me.lbl6.AutoSize = True
        Me.lbl6.Location = New System.Drawing.Point(21, 188)
        Me.lbl6.Name = "lbl6"
        Me.lbl6.Size = New System.Drawing.Size(100, 13)
        Me.lbl6.TabIndex = 32
        Me.lbl6.Text = "Date of Termination"
        '
        'lbl4
        '
        Me.lbl4.AutoSize = True
        Me.lbl4.Location = New System.Drawing.Point(21, 160)
        Me.lbl4.Name = "lbl4"
        Me.lbl4.Size = New System.Drawing.Size(64, 13)
        Me.lbl4.TabIndex = 30
        Me.lbl4.Text = "Date of Hire"
        '
        'lbl3
        '
        Me.lbl3.AutoSize = True
        Me.lbl3.Location = New System.Drawing.Point(21, 120)
        Me.lbl3.Name = "lbl3"
        Me.lbl3.Size = New System.Drawing.Size(67, 13)
        Me.lbl3.TabIndex = 29
        Me.lbl3.Text = "Employee ID"
        '
        'lbl2
        '
        Me.lbl2.AutoSize = True
        Me.lbl2.Location = New System.Drawing.Point(21, 78)
        Me.lbl2.Name = "lbl2"
        Me.lbl2.Size = New System.Drawing.Size(61, 13)
        Me.lbl2.TabIndex = 28
        Me.lbl2.Text = "Last Name:"
        '
        'lbl1
        '
        Me.lbl1.AutoSize = True
        Me.lbl1.Location = New System.Drawing.Point(21, 35)
        Me.lbl1.Name = "lbl1"
        Me.lbl1.Size = New System.Drawing.Size(60, 13)
        Me.lbl1.TabIndex = 27
        Me.lbl1.Text = "First Name:"
        '
        'txtDateTerm
        '
        Me.txtDateTerm.Location = New System.Drawing.Point(137, 188)
        Me.txtDateTerm.Name = "txtDateTerm"
        Me.txtDateTerm.Size = New System.Drawing.Size(100, 20)
        Me.txtDateTerm.TabIndex = 21
        '
        'txtEmployeeID
        '
        Me.txtEmployeeID.Location = New System.Drawing.Point(137, 113)
        Me.txtEmployeeID.Name = "txtEmployeeID"
        Me.txtEmployeeID.Size = New System.Drawing.Size(100, 20)
        Me.txtEmployeeID.TabIndex = 20
        '
        'txtLastName
        '
        Me.txtLastName.Location = New System.Drawing.Point(137, 71)
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(100, 20)
        Me.txtLastName.TabIndex = 19
        '
        'txtFirstName
        '
        Me.txtFirstName.Location = New System.Drawing.Point(137, 29)
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(100, 20)
        Me.txtFirstName.TabIndex = 18
        '
        'frmUpdateAttendant
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(623, 610)
        Me.Controls.Add(Me.cboUpdate)
        Me.Controls.Add(Me.lbl10)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnSubmit)
        Me.Controls.Add(Me.gpbUpdate)
        Me.Name = "frmUpdateAttendant"
        Me.Text = "frmUpdateAttendant"
        Me.gpbUpdate.ResumeLayout(False)
        Me.gpbUpdate.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents cboUpdate As ComboBox
    Friend WithEvents lbl10 As Label
    Friend WithEvents btnExit As Button
    Friend WithEvents btnSubmit As Button
    Friend WithEvents gpbUpdate As GroupBox
    Friend WithEvents txtDateHire As TextBox
    Friend WithEvents lbl6 As Label
    Friend WithEvents lbl4 As Label
    Friend WithEvents lbl3 As Label
    Friend WithEvents lbl2 As Label
    Friend WithEvents lbl1 As Label
    Friend WithEvents txtDateTerm As TextBox
    Friend WithEvents txtEmployeeID As TextBox
    Friend WithEvents txtLastName As TextBox
    Friend WithEvents txtFirstName As TextBox
End Class
