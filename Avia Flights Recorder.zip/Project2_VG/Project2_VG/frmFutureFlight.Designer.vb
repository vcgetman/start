﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmFutureFlight
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblMiles = New System.Windows.Forms.Label()
        Me.lbl2 = New System.Windows.Forms.Label()
        Me.lstPassengerPastFlight = New System.Windows.Forms.ListBox()
        Me.lblPassengerName = New System.Windows.Forms.Label()
        Me.cboPassenger = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(263, 726)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(199, 57)
        Me.btnExit.TabIndex = 21
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'lblMiles
        '
        Me.lblMiles.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.lblMiles.Location = New System.Drawing.Point(539, 149)
        Me.lblMiles.Name = "lblMiles"
        Me.lblMiles.Size = New System.Drawing.Size(344, 32)
        Me.lblMiles.TabIndex = 20
        '
        'lbl2
        '
        Me.lbl2.AutoSize = True
        Me.lbl2.Location = New System.Drawing.Point(258, 152)
        Me.lbl2.Name = "lbl2"
        Me.lbl2.Size = New System.Drawing.Size(89, 29)
        Me.lbl2.TabIndex = 19
        Me.lbl2.Text = "Miles : "
        '
        'lstPassengerPastFlight
        '
        Me.lstPassengerPastFlight.FormattingEnabled = True
        Me.lstPassengerPastFlight.ItemHeight = 29
        Me.lstPassengerPastFlight.Location = New System.Drawing.Point(258, 200)
        Me.lstPassengerPastFlight.Margin = New System.Windows.Forms.Padding(1)
        Me.lstPassengerPastFlight.Name = "lstPassengerPastFlight"
        Me.lstPassengerPastFlight.Size = New System.Drawing.Size(625, 352)
        Me.lstPassengerPastFlight.TabIndex = 18
        '
        'lblPassengerName
        '
        Me.lblPassengerName.AutoSize = True
        Me.lblPassengerName.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPassengerName.Location = New System.Drawing.Point(252, 91)
        Me.lblPassengerName.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lblPassengerName.Name = "lblPassengerName"
        Me.lblPassengerName.Size = New System.Drawing.Size(265, 36)
        Me.lblPassengerName.TabIndex = 17
        Me.lblPassengerName.Text = "Passenger Name:"
        '
        'cboPassenger
        '
        Me.cboPassenger.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboPassenger.FormattingEnabled = True
        Me.cboPassenger.Location = New System.Drawing.Point(664, 91)
        Me.cboPassenger.Margin = New System.Windows.Forms.Padding(1)
        Me.cboPassenger.Name = "cboPassenger"
        Me.cboPassenger.Size = New System.Drawing.Size(219, 44)
        Me.cboPassenger.TabIndex = 16
        '
        'frmFutureFlight
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(14.0!, 29.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1135, 875)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.lblMiles)
        Me.Controls.Add(Me.lbl2)
        Me.Controls.Add(Me.lstPassengerPastFlight)
        Me.Controls.Add(Me.lblPassengerName)
        Me.Controls.Add(Me.cboPassenger)
        Me.Name = "frmFutureFlight"
        Me.Text = "frmFutureFlight"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnExit As Button
    Friend WithEvents lblMiles As Label
    Friend WithEvents lbl2 As Label
    Friend WithEvents lstPassengerPastFlight As ListBox
    Friend WithEvents lblPassengerName As Label
    Friend WithEvents cboPassenger As ComboBox
End Class
