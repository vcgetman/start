﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmUpdatePilot2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.gpbUpdate = New System.Windows.Forms.GroupBox()
        Me.txtDateOfHire = New System.Windows.Forms.TextBox()
        Me.lbl4 = New System.Windows.Forms.Label()
        Me.lbl3 = New System.Windows.Forms.Label()
        Me.lbl2 = New System.Windows.Forms.Label()
        Me.lbl1 = New System.Windows.Forms.Label()
        Me.txtEmployeeID = New System.Windows.Forms.TextBox()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.cboUpdatePilot = New System.Windows.Forms.ComboBox()
        Me.lbl10 = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnSubmit = New System.Windows.Forms.Button()
        Me.gpbUpdate.SuspendLayout()
        Me.SuspendLayout()
        '
        'gpbUpdate
        '
        Me.gpbUpdate.Controls.Add(Me.txtDateOfHire)
        Me.gpbUpdate.Controls.Add(Me.lbl4)
        Me.gpbUpdate.Controls.Add(Me.lbl3)
        Me.gpbUpdate.Controls.Add(Me.lbl2)
        Me.gpbUpdate.Controls.Add(Me.lbl1)
        Me.gpbUpdate.Controls.Add(Me.txtEmployeeID)
        Me.gpbUpdate.Controls.Add(Me.txtLastName)
        Me.gpbUpdate.Controls.Add(Me.txtFirstName)
        Me.gpbUpdate.Location = New System.Drawing.Point(133, 82)
        Me.gpbUpdate.Margin = New System.Windows.Forms.Padding(2)
        Me.gpbUpdate.Name = "gpbUpdate"
        Me.gpbUpdate.Padding = New System.Windows.Forms.Padding(2)
        Me.gpbUpdate.Size = New System.Drawing.Size(831, 462)
        Me.gpbUpdate.TabIndex = 36
        Me.gpbUpdate.TabStop = False
        Me.gpbUpdate.Text = "Update Pilot Info"
        '
        'txtDateOfHire
        '
        Me.txtDateOfHire.Location = New System.Drawing.Point(320, 350)
        Me.txtDateOfHire.Margin = New System.Windows.Forms.Padding(7)
        Me.txtDateOfHire.Name = "txtDateOfHire"
        Me.txtDateOfHire.Size = New System.Drawing.Size(228, 35)
        Me.txtDateOfHire.TabIndex = 36
        '
        'lbl4
        '
        Me.lbl4.AutoSize = True
        Me.lbl4.Location = New System.Drawing.Point(49, 357)
        Me.lbl4.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.lbl4.Name = "lbl4"
        Me.lbl4.Size = New System.Drawing.Size(140, 29)
        Me.lbl4.TabIndex = 30
        Me.lbl4.Text = "Date of Hire"
        '
        'lbl3
        '
        Me.lbl3.AutoSize = True
        Me.lbl3.Location = New System.Drawing.Point(49, 268)
        Me.lbl3.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.lbl3.Name = "lbl3"
        Me.lbl3.Size = New System.Drawing.Size(151, 29)
        Me.lbl3.TabIndex = 29
        Me.lbl3.Text = "EmployeeID:"
        '
        'lbl2
        '
        Me.lbl2.AutoSize = True
        Me.lbl2.Location = New System.Drawing.Point(49, 174)
        Me.lbl2.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.lbl2.Name = "lbl2"
        Me.lbl2.Size = New System.Drawing.Size(134, 29)
        Me.lbl2.TabIndex = 28
        Me.lbl2.Text = "Last Name:"
        '
        'lbl1
        '
        Me.lbl1.AutoSize = True
        Me.lbl1.Location = New System.Drawing.Point(49, 78)
        Me.lbl1.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.lbl1.Name = "lbl1"
        Me.lbl1.Size = New System.Drawing.Size(137, 29)
        Me.lbl1.TabIndex = 27
        Me.lbl1.Text = "First Name:"
        '
        'txtEmployeeID
        '
        Me.txtEmployeeID.Location = New System.Drawing.Point(320, 252)
        Me.txtEmployeeID.Margin = New System.Windows.Forms.Padding(7)
        Me.txtEmployeeID.Name = "txtEmployeeID"
        Me.txtEmployeeID.Size = New System.Drawing.Size(228, 35)
        Me.txtEmployeeID.TabIndex = 20
        '
        'txtLastName
        '
        Me.txtLastName.Location = New System.Drawing.Point(320, 158)
        Me.txtLastName.Margin = New System.Windows.Forms.Padding(7)
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(228, 35)
        Me.txtLastName.TabIndex = 19
        '
        'txtFirstName
        '
        Me.txtFirstName.Location = New System.Drawing.Point(320, 65)
        Me.txtFirstName.Margin = New System.Windows.Forms.Padding(7)
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(228, 35)
        Me.txtFirstName.TabIndex = 18
        '
        'cboUpdatePilot
        '
        Me.cboUpdatePilot.FormattingEnabled = True
        Me.cboUpdatePilot.Location = New System.Drawing.Point(463, 29)
        Me.cboUpdatePilot.Margin = New System.Windows.Forms.Padding(2)
        Me.cboUpdatePilot.Name = "cboUpdatePilot"
        Me.cboUpdatePilot.Size = New System.Drawing.Size(569, 37)
        Me.cboUpdatePilot.TabIndex = 41
        '
        'lbl10
        '
        Me.lbl10.AutoSize = True
        Me.lbl10.Location = New System.Drawing.Point(80, 29)
        Me.lbl10.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.lbl10.Name = "lbl10"
        Me.lbl10.Size = New System.Drawing.Size(251, 29)
        Me.lbl10.TabIndex = 40
        Me.lbl10.Text = "Select Pilot to Update:"
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(629, 612)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(2)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(261, 71)
        Me.btnExit.TabIndex = 43
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'btnSubmit
        '
        Me.btnSubmit.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnSubmit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnSubmit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSubmit.Location = New System.Drawing.Point(202, 612)
        Me.btnSubmit.Margin = New System.Windows.Forms.Padding(2)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(261, 71)
        Me.btnSubmit.TabIndex = 42
        Me.btnSubmit.Text = "Submit"
        Me.btnSubmit.UseVisualStyleBackColor = False
        '
        'frmUpdatePilot2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(14.0!, 29.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1172, 1085)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnSubmit)
        Me.Controls.Add(Me.cboUpdatePilot)
        Me.Controls.Add(Me.lbl10)
        Me.Controls.Add(Me.gpbUpdate)
        Me.Name = "frmUpdatePilot2"
        Me.Text = "frmUpdatePilot2"
        Me.gpbUpdate.ResumeLayout(False)
        Me.gpbUpdate.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents gpbUpdate As GroupBox
    Friend WithEvents txtDateOfHire As TextBox
    Friend WithEvents lbl4 As Label
    Friend WithEvents lbl3 As Label
    Friend WithEvents lbl2 As Label
    Friend WithEvents lbl1 As Label
    Friend WithEvents txtEmployeeID As TextBox
    Friend WithEvents txtLastName As TextBox
    Friend WithEvents txtFirstName As TextBox
    Friend WithEvents cboUpdatePilot As ComboBox
    Friend WithEvents lbl10 As Label
    Friend WithEvents btnExit As Button
    Friend WithEvents btnSubmit As Button
End Class
