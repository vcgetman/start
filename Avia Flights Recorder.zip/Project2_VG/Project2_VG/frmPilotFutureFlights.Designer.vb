﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPilotFutureFlights
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblMiles = New System.Windows.Forms.Label()
        Me.lbl2 = New System.Windows.Forms.Label()
        Me.lstPilotFutureFlight = New System.Windows.Forms.ListBox()
        Me.lblPilotName = New System.Windows.Forms.Label()
        Me.cboPilot = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(74, 695)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(199, 57)
        Me.btnExit.TabIndex = 27
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'lblMiles
        '
        Me.lblMiles.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.lblMiles.Location = New System.Drawing.Point(350, 129)
        Me.lblMiles.Name = "lblMiles"
        Me.lblMiles.Size = New System.Drawing.Size(504, 32)
        Me.lblMiles.TabIndex = 26
        '
        'lbl2
        '
        Me.lbl2.AutoSize = True
        Me.lbl2.Location = New System.Drawing.Point(69, 132)
        Me.lbl2.Name = "lbl2"
        Me.lbl2.Size = New System.Drawing.Size(89, 29)
        Me.lbl2.TabIndex = 25
        Me.lbl2.Text = "Miles : "
        '
        'lstPilotFutureFlight
        '
        Me.lstPilotFutureFlight.FormattingEnabled = True
        Me.lstPilotFutureFlight.ItemHeight = 29
        Me.lstPilotFutureFlight.Location = New System.Drawing.Point(69, 194)
        Me.lstPilotFutureFlight.Margin = New System.Windows.Forms.Padding(1)
        Me.lstPilotFutureFlight.Name = "lstPilotFutureFlight"
        Me.lstPilotFutureFlight.Size = New System.Drawing.Size(785, 352)
        Me.lstPilotFutureFlight.TabIndex = 24
        '
        'lblPilotName
        '
        Me.lblPilotName.AutoSize = True
        Me.lblPilotName.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPilotName.Location = New System.Drawing.Point(63, 60)
        Me.lblPilotName.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lblPilotName.Name = "lblPilotName"
        Me.lblPilotName.Size = New System.Drawing.Size(178, 36)
        Me.lblPilotName.TabIndex = 23
        Me.lblPilotName.Text = "Pilot Name:"
        '
        'cboPilot
        '
        Me.cboPilot.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboPilot.FormattingEnabled = True
        Me.cboPilot.Location = New System.Drawing.Point(475, 60)
        Me.cboPilot.Margin = New System.Windows.Forms.Padding(1)
        Me.cboPilot.Name = "cboPilot"
        Me.cboPilot.Size = New System.Drawing.Size(379, 44)
        Me.cboPilot.TabIndex = 22
        '
        'frmPilotFutureFlights
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(14.0!, 29.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1018, 1016)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.lblMiles)
        Me.Controls.Add(Me.lbl2)
        Me.Controls.Add(Me.lstPilotFutureFlight)
        Me.Controls.Add(Me.lblPilotName)
        Me.Controls.Add(Me.cboPilot)
        Me.Name = "frmPilotFutureFlights"
        Me.Text = "frmPilotFutureFlights"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnExit As Button
    Friend WithEvents lblMiles As Label
    Friend WithEvents lbl2 As Label
    Friend WithEvents lstPilotFutureFlight As ListBox
    Friend WithEvents lblPilotName As Label
    Friend WithEvents cboPilot As ComboBox
End Class
