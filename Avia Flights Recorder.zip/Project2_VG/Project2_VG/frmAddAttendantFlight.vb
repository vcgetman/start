﻿Public Class frmAddAttendantFlight
    Private Sub frmAddAttendantFlight_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try

            Dim strSelect As String = ""
            Dim cmdSelect As OleDb.OleDbCommand            ' this will be used for our Select statement
            Dim drSourceTable As OleDb.OleDbDataReader     ' this will be where our result set will 
            Dim dt As DataTable = New DataTable            ' this is the table we will load from our reader
            Dim dtFlight As DataTable = New DataTable

            ' open the DB
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                            "The application will now close.",
                                            Me.Text + " Error",
                                            MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()

            End If

            strSelect = "SELECT intAttendantID, strFirstName + ' ' + strLastName as AttendantName FROM TAttendants"

            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader

            ' load table from data reader
            dt.Load(drSourceTable)

            'load the Last Name result set into the combobox.  For VB, we do this by binding the data to the combobox

            cboAttendant.ValueMember = "intAttendantID"
            cboAttendant.DisplayMember = "AttendantName"
            cboAttendant.DataSource = dt

            ' Build the select statement
            strSelect = "SELECT intFlightID, strFlightNumber  FROM TFlights"


            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader

            ' load table from data reader
            dtFlight.Load(drSourceTable)

            ' Add the item to the combo box. We need the player ID associated with the name so 
            ' when we click on the name we can then use the ID to pull the rest of the players data.
            ' We are binding the column name to the combo box display and value members. 
            cboFlight.ValueMember = "intFlightID"
            cboFlight.DisplayMember = "strFlightNumber"
            cboFlight.DataSource = dtFlight

            ' Clean up
            drSourceTable.Close()

            ' close the database connection
            CloseDatabaseConnection()

        Catch ex As Exception

            ' Log and display error message
            MessageBox.Show(ex.Message)

        End Try
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub

    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click


        Dim strSelect As String
        Dim intRowsAffected As Integer

        ' thie will hold our Update statement
        Dim cmdUpdate As OleDb.OleDbCommand

        Try


            ' open database this is in module
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                        "The application will now close.",
                                        Me.Text + " Error",
                                        MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()

            End If


            cboAttendant = cboAttendant.SelectedValue
            cboFlight = cboFlight.SelectedValue


            ' Build the select statement using PK from name selected


            strSelect = (" SELECT TP.intPilotID, TF.strFlightNumber, TF.dtmFlightDate, TF.dtmTimeofDeparture, TF.dtmTimeOfLanding, TF.intMilesFlown " +
                        " FROM TPilots as TP Join TPilotFlights as TPF " +
                        " On TP.intPilotID = TPF.intPilotID " +
                        " Join TFlights as TF " +
                        " On TPF.intFlightID = TF.intFlightID " +
                        " Where TP.intPilotID = " & cboAttendant.SelectedValue)

            ' uncomment out the following message box line to use as a tool to check your sql statement
            ' remember anything not a numeric value going into SQL Server must have single quotes '
            ' around it, including dates.

            MessageBox.Show(strSelect)

            ' make the connection
            cmdUpdate = New OleDb.OleDbCommand(strSelect, m_conAdministrator)

            ' IUpdate the row with execute the statement
            intRowsAffected = cmdUpdate.ExecuteNonQuery()

            ' have to let the user know what happened 
            If intRowsAffected = 1 Then
                MessageBox.Show("Pilot assigned to flight successfully")
            Else
                MessageBox.Show("Connection failed")
            End If

            ' close the database connection
            CloseDatabaseConnection()

            Close()


        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

End Class