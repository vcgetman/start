﻿Public Class frmPilotPastFlights
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub

    Private Sub frmPilotPastFlights_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim strSelect As String = ""
        Dim cmdSelect As OleDb.OleDbCommand ' this will be used for our Select statement
        Dim drSourceTable As OleDb.OleDbDataReader ' this will be where our data is retrieved to
        Dim dt As DataTable = New DataTable ' this is the table we will load from our reader
        Try
            ' loop through the textboxes and clear them in case they have data in them after a delete
            For Each cntrl As Control In Controls
                If TypeOf cntrl Is TextBox Then
                    cntrl.Text = String.Empty
                End If
            Next

            ' open the DB this is in module
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                "The application will now close.",
                                Me.Text + " Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()

            End If


            ' Build the select statement

            strSelect = "SELECT intPilotID, strFirstName + ' ' + strLastName as PilotName FROM TPilots"

            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader

            ' load table from data reader
            dt.Load(drSourceTable)

            'load the Last Name result set into the combobox.  For VB, we do this by binding the data to the combobox


            cboPilot.ValueMember = "intPilotID"
            cboPilot.DisplayMember = "PilotName"
            cboPilot.DataSource = dt

            ' Select the first item in the list by default
            If cboPilot.Items.Count > 0 Then cboPilot.SelectedIndex = 0

            ' Clean up
            drSourceTable.Close()

            ' close the database connection
            CloseDatabaseConnection()

        Catch excError As Exception

            ' Log and display error message
            MessageBox.Show(excError.Message)

        End Try
    End Sub

    Private Sub cboPilot_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboPilot.SelectedIndexChanged
        Dim strSelect As String = ""
        Dim strLastName As String = ""
        Dim cmdSelect As OleDb.OleDbCommand ' this will be used for our Select statement
        Dim drSourceTable As OleDb.OleDbDataReader ' this will be where our data is retrieved to
        Dim dt As DataTable = New DataTable ' this is the table we will load from our reader


        Try


            ' open the database this is in module
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()

            End If

            ' Build the select statement using PK from name selected
            strSelect = (" SELECT TP.intPilotID, TF.strFlightNumber, TF.dtmFlightDate, TF.dtmTimeofDeparture, TF.dtmTimeOfLanding, TF.intMilesFlown " +
                        " FROM TPilots as TP Join TPilotFlights as TPF " +
                        " On TP.intPilotID = TPF.intPilotID " +
                        " Join TFlights as TF " +
                        " On TPF.intFlightID = TF.intFlightID " +
                        " Where TP.intPilotID = " & cboPilot.SelectedValue)

            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader



            lstPilotPastFlight.Items.Clear()


            ' populate the text boxes with the data
            lstPilotPastFlight.Items.Add("=============================")


            While drSourceTable.Read()

                lstPilotPastFlight.Items.Add("  ")

                lstPilotPastFlight.Items.Add("Flight Number: " & vbTab & drSourceTable("strFlightNumber"))
                lstPilotPastFlight.Items.Add("Flight Date : " & vbTab & drSourceTable("dtmFlightDate"))
                lstPilotPastFlight.Items.Add("Departure Time: " & vbTab & drSourceTable("dtmTimeofDeparture"))
                lstPilotPastFlight.Items.Add("Arrival Time : " & vbTab & drSourceTable("dtmTimeOfLanding"))
                lstPilotPastFlight.Items.Add("Miles Flown : " & vbTab & drSourceTable("intMilesFlown"))

                lstPilotPastFlight.Items.Add("  ")
                lstPilotPastFlight.Items.Add("=============================")
                lblMiles.Text = CInt(drSourceTable("intMilesFlown"))
            End While


            ' close the database connection
            CloseDatabaseConnection()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try


        'End While



    End Sub
End Class