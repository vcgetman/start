﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmStatistics
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblTotalNumberPassengers = New System.Windows.Forms.Label()
        Me.lbl2 = New System.Windows.Forms.Label()
        Me.lstStatistics = New System.Windows.Forms.ListBox()
        Me.lblTotalFlightsPassengers = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblAvgMilesFlown = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(72, 323)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(1)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(85, 26)
        Me.btnExit.TabIndex = 25
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'lblTotalNumberPassengers
        '
        Me.lblTotalNumberPassengers.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.lblTotalNumberPassengers.Location = New System.Drawing.Point(271, 210)
        Me.lblTotalNumberPassengers.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lblTotalNumberPassengers.Name = "lblTotalNumberPassengers"
        Me.lblTotalNumberPassengers.Size = New System.Drawing.Size(147, 14)
        Me.lblTotalNumberPassengers.TabIndex = 24
        '
        'lbl2
        '
        Me.lbl2.AutoSize = True
        Me.lbl2.Location = New System.Drawing.Point(72, 211)
        Me.lbl2.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lbl2.Name = "lbl2"
        Me.lbl2.Size = New System.Drawing.Size(141, 13)
        Me.lbl2.TabIndex = 23
        Me.lbl2.Text = "Total Number of Passengers"
        '
        'lstStatistics
        '
        Me.lstStatistics.FormattingEnabled = True
        Me.lstStatistics.Location = New System.Drawing.Point(72, 38)
        Me.lstStatistics.Margin = New System.Windows.Forms.Padding(0)
        Me.lstStatistics.Name = "lstStatistics"
        Me.lstStatistics.Size = New System.Drawing.Size(346, 160)
        Me.lstStatistics.TabIndex = 22
        '
        'lblTotalFlightsPassengers
        '
        Me.lblTotalFlightsPassengers.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.lblTotalFlightsPassengers.Location = New System.Drawing.Point(271, 237)
        Me.lblTotalFlightsPassengers.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lblTotalFlightsPassengers.Name = "lblTotalFlightsPassengers"
        Me.lblTotalFlightsPassengers.Size = New System.Drawing.Size(147, 14)
        Me.lblTotalFlightsPassengers.TabIndex = 27
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(72, 238)
        Me.Label2.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(136, 13)
        Me.Label2.TabIndex = 26
        Me.Label2.Text = "Total Flights by Passengers"
        '
        'lblAvgMilesFlown
        '
        Me.lblAvgMilesFlown.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.lblAvgMilesFlown.Location = New System.Drawing.Point(271, 263)
        Me.lblAvgMilesFlown.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lblAvgMilesFlown.Name = "lblAvgMilesFlown"
        Me.lblAvgMilesFlown.Size = New System.Drawing.Size(147, 14)
        Me.lblAvgMilesFlown.TabIndex = 29
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(72, 264)
        Me.Label3.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(187, 13)
        Me.Label3.TabIndex = 28
        Me.Label3.Text = "Average miles flown for all Passengers"
        '
        'frmStatistics
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.lblAvgMilesFlown)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.lblTotalFlightsPassengers)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.lblTotalNumberPassengers)
        Me.Controls.Add(Me.lbl2)
        Me.Controls.Add(Me.lstStatistics)
        Me.Name = "frmStatistics"
        Me.Text = "frmStatistics"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnExit As Button
    Friend WithEvents lblTotalNumberPassengers As Label
    Friend WithEvents lbl2 As Label
    Friend WithEvents lstStatistics As ListBox
    Friend WithEvents lblTotalFlightsPassengers As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents lblAvgMilesFlown As Label
    Friend WithEvents Label3 As Label
End Class
