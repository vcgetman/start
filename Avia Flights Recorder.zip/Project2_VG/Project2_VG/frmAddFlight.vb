﻿Public Class frmAddFlight


    Private Sub frmAddFlight_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Try

            Dim strSelect As String = ""
            Dim cmdSelect As OleDb.OleDbCommand ' this will be used for our Select statement
            Dim drSourceTable As OleDb.OleDbDataReader ' this will be where our data is retrieved to
            Dim dt As DataTable = New DataTable ' this is the table we will load from our reader 
            Dim dta As DataTable = New DataTable ' this is the table we will load from our reader for FromAirport
            Dim dtato As DataTable = New DataTable ' this is the table we will load from our reader for ToAirport
            Dim dtmiles As DataTable = New DataTable ' this is the table we will load from our reader for Miles
            Dim dtplane As DataTable = New DataTable ' this is the table we will load from our reader for Plane

            ' open the DB
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()

            End If

            ' Build the select statement to obtain States
            strSelect = "SELECT intAirportID, strAirportCity FROM TAirports"

            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader
            dta.Load(drSourceTable)

            'load the Airports result set into the combobox.  For VB, we do this by binding the data to the combobox

            cboFromAirport.ValueMember = "intAirportID"
            cboFromAirport.DisplayMember = "strAirportCity"
            cboFromAirport.DataSource = dta

            ' Build the select statement to obtain States
            strSelect = "SELECT intAirportID, strAirportCity FROM TAirports"

            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader
            dtato.Load(drSourceTable)

            'load the Airports result set into the combobox.  For VB, we do this by binding the data to the combobox

            cboToAirport.ValueMember = "intAirportID"
            cboToAirport.DisplayMember = "strAirportCity"
            cboToAirport.DataSource = dtato

            ' Build the select statement to obtain States
            strSelect = "SELECT intPlaneID, strPlaneNumber FROM TPlanes"

            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader
            dtplane.Load(drSourceTable)

            'load the Airports result set into the combobox.  For VB, we do this by binding the data to the combobox

            cboPlane.ValueMember = "intPlaneID"
            cboPlane.DisplayMember = "strPlaneNumber"
            cboPlane.DataSource = dtplane

            ' Build the select statement to obtain States
            strSelect = "SELECT intMilesFlown FROM TFlights"

            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader
            dtmiles.Load(drSourceTable)

            'load the Airports result set into the combobox.  For VB, we do this by binding the data to the combobox

            cboMiles.ValueMember = "intFlownMiles"
            cboMiles.DisplayMember = "intFlownMiles"
            cboMiles.DataSource = dtmiles

            ' Build the select statement
            strSelect = "SELECT intFlightID, strFlightNumber as FlightNumber FROM TFlights"

            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader

            ' load table from data reader
            dt.Load(drSourceTable)

            ' Add the item to the combo box. We need the flight ID associated with the name so 
            ' when we click on the name we can then use the ID to pull the rest of the players data.
            ' We are binding the column name to the combo box display and value members. 
            cboSelectFlight.ValueMember = "intFlightID"
            cboSelectFlight.DisplayMember = "FlightNumber"
            cboSelectFlight.DataSource = dt

            ' Select the first item in the list by default
            If cboSelectFlight.Items.Count > 0 Then cboSelectFlight.SelectedIndex = 0


            ' Clean up
            drSourceTable.Close()

            ' close the database connection
            CloseDatabaseConnection()

        Catch ex As Exception

            ' Log and display error message
            MessageBox.Show(ex.Message)

        End Try
    End Sub

    Private Sub cboUpdate_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboSelectFlight.SelectedIndexChanged
        'this Sub() Is called anytime the selected item Is changed in the combo box.

        Dim strSelect As String = ""
        Dim strName As String = ""
        Dim cmdSelect As OleDb.OleDbCommand ' this will be used for our Select statement
        Dim drSourceTable As OleDb.OleDbDataReader ' this will be where our data is retrieved to
        Dim dt As DataTable = New DataTable ' this is the table we will load from our reader


        Try


            ' open the database this is in module
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()

            End If

            ' Build the select statement using PK from name selected
            strSelect = "SELECT dtmFlightDate, strFlightNumber,  dtmTimeofDeparture, dtmTimeOfLanding, intFromAirportID, intToAirportID, intMilesFlown, intPlaneID " &
                        " FROM TFlights Where intFlightID = " & cboSelectFlight.SelectedValue

            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader

            drSourceTable.Read()


            ' populate the text boxes with the data
            txtFlightDate.Text = drSourceTable("dtmFlightDate")
            txtFlightNumber.Text = drSourceTable("strFlightNumber")
            txtDepTime.Text = drSourceTable("dtmTimeofDeparture")
            txtArrTime.Text = drSourceTable("dtmTimeOfLanding")
            cboFromAirport.SelectedValue = drSourceTable("intAirportID")
            cboToAirport.SelectedValue = drSourceTable("intAirportID")
            cboMiles.SelectedValue = drSourceTable("intMilesFlown")
            cboPlane.SelectedValue = drSourceTable("intPlaneID")



            ' close the database connection
            CloseDatabaseConnection()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try


    End Sub

    Private Sub btnSelect_Click(sender As Object, e As EventArgs) Handles btnSelect.Click

        Dim strSelect As String
        Dim dtmFlightDate As String
        Dim strFlightNumber As String
        Dim dtmTimeofDeparture As String
        Dim dtmTimeOfLanding As String
        Dim intAirportID As Integer
        Dim intMilesFlown As String
        Dim intPlaneID As String
        Dim intRowsAffected As Integer

        ' thie will hold our Update statement
        Dim cmdUpdate As OleDb.OleDbCommand

        Try


            ' open database this is in module
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                        "The application will now close.",
                                        Me.Text + " Error",
                                        MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()

            End If

            dtmFlightDate = txtFlightDate.Text
            strFlightNumber = txtFlightNumber.Text
            dtmTimeofDeparture = txtDepTime.Text
            dtmTimeOfLanding = txtArrTime.Text
            intAirportID = cboFromAirport.SelectedValue
            intAirportID = cboToAirport.SelectedValue
            intMilesFlown = cboMiles.SelectedValue
            intPlaneID = cboPlane.SelectedValue


            ' Build the select statement using PK from name selected
            strSelect = "Update TFlights Set " &
                        "dtmFlightDate = '" & dtmFlightDate & "', " &
                        "strFlightNumber = '" & strFlightNumber & "', " &
                        "dtmTimeofDeparture = '" & dtmTimeofDeparture & "', " &
                        "dtmTimeOfLanding = '" & dtmTimeOfLanding & "', " &
                        "intFromAirportID = " & intAirportID & ", " &
                        "intToAirportID = " & intAirportID & ", " &
                        "intMilesFlown = " & intMilesFlown & ", " &
                        "intPlaneID = " & intPlaneID & "" &
                        "Where intFlightID = " & cboSelectFlight.SelectedValue


            ' uncomment out the following message box line to use as a tool to check your sql statement
            ' remember anything not a numeric value going into SQL Server must have single quotes '
            ' around it, including dates.

            MessageBox.Show(strSelect)

            ' make the connection
            cmdUpdate = New OleDb.OleDbCommand(strSelect, m_conAdministrator)

            ' IUpdate the row with execute the statement
            intRowsAffected = cmdUpdate.ExecuteNonQuery()

            ' have to let the user know what happened 
            If intRowsAffected = 1 Then
                MessageBox.Show("Update successful")
            Else
                MessageBox.Show("Update failed")
            End If

            ' close the database connection
            CloseDatabaseConnection()

            Close()


        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub

End Class