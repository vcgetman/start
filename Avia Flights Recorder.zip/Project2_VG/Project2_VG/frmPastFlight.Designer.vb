﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPastFlight
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lstPassengerPastFlight = New System.Windows.Forms.ListBox()
        Me.lblPassengerName = New System.Windows.Forms.Label()
        Me.cboPassenger = New System.Windows.Forms.ComboBox()
        Me.lbl2 = New System.Windows.Forms.Label()
        Me.lblMiles = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lstPassengerPastFlight
        '
        Me.lstPassengerPastFlight.FormattingEnabled = True
        Me.lstPassengerPastFlight.ItemHeight = 29
        Me.lstPassengerPastFlight.Location = New System.Drawing.Point(195, 220)
        Me.lstPassengerPastFlight.Margin = New System.Windows.Forms.Padding(1)
        Me.lstPassengerPastFlight.Name = "lstPassengerPastFlight"
        Me.lstPassengerPastFlight.Size = New System.Drawing.Size(625, 352)
        Me.lstPassengerPastFlight.TabIndex = 5
        '
        'lblPassengerName
        '
        Me.lblPassengerName.AutoSize = True
        Me.lblPassengerName.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPassengerName.Location = New System.Drawing.Point(189, 86)
        Me.lblPassengerName.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lblPassengerName.Name = "lblPassengerName"
        Me.lblPassengerName.Size = New System.Drawing.Size(265, 36)
        Me.lblPassengerName.TabIndex = 4
        Me.lblPassengerName.Text = "Passenger Name:"
        '
        'cboPassenger
        '
        Me.cboPassenger.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboPassenger.FormattingEnabled = True
        Me.cboPassenger.Location = New System.Drawing.Point(601, 86)
        Me.cboPassenger.Margin = New System.Windows.Forms.Padding(1)
        Me.cboPassenger.Name = "cboPassenger"
        Me.cboPassenger.Size = New System.Drawing.Size(219, 44)
        Me.cboPassenger.TabIndex = 3
        '
        'lbl2
        '
        Me.lbl2.AutoSize = True
        Me.lbl2.Location = New System.Drawing.Point(195, 158)
        Me.lbl2.Name = "lbl2"
        Me.lbl2.Size = New System.Drawing.Size(89, 29)
        Me.lbl2.TabIndex = 6
        Me.lbl2.Text = "Miles : "
        '
        'lblMiles
        '
        Me.lblMiles.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.lblMiles.Location = New System.Drawing.Point(476, 155)
        Me.lblMiles.Name = "lblMiles"
        Me.lblMiles.Size = New System.Drawing.Size(344, 32)
        Me.lblMiles.TabIndex = 7
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(200, 721)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(199, 57)
        Me.btnExit.TabIndex = 15
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'frmPastFlight
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(14.0!, 29.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(979, 915)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.lblMiles)
        Me.Controls.Add(Me.lbl2)
        Me.Controls.Add(Me.lstPassengerPastFlight)
        Me.Controls.Add(Me.lblPassengerName)
        Me.Controls.Add(Me.cboPassenger)
        Me.Name = "frmPastFlight"
        Me.Text = "frmPastFlight"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lstPassengerPastFlight As ListBox
    Friend WithEvents lblPassengerName As Label
    Friend WithEvents cboPassenger As ComboBox
    Friend WithEvents lbl2 As Label
    Friend WithEvents lblMiles As Label
    Friend WithEvents btnExit As Button
End Class
