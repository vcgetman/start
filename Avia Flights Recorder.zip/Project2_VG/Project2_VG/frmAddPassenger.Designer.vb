﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAddPassenger
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnSubmit = New System.Windows.Forms.Button()
        Me.gpbAdd = New System.Windows.Forms.GroupBox()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.txtCity = New System.Windows.Forms.TextBox()
        Me.lbl9 = New System.Windows.Forms.Label()
        Me.lbl7 = New System.Windows.Forms.Label()
        Me.lbl6 = New System.Windows.Forms.Label()
        Me.lbl5 = New System.Windows.Forms.Label()
        Me.lbl4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lbl2 = New System.Windows.Forms.Label()
        Me.lbl1 = New System.Windows.Forms.Label()
        Me.cboStates = New System.Windows.Forms.ComboBox()
        Me.txtPhone = New System.Windows.Forms.TextBox()
        Me.txtZip = New System.Windows.Forms.TextBox()
        Me.txtAddress = New System.Windows.Forms.TextBox()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.gpbAdd.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(730, 999)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(262, 71)
        Me.btnExit.TabIndex = 11
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'btnSubmit
        '
        Me.btnSubmit.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnSubmit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnSubmit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSubmit.Location = New System.Drawing.Point(302, 999)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(262, 71)
        Me.btnSubmit.TabIndex = 10
        Me.btnSubmit.Text = "Submit"
        Me.btnSubmit.UseVisualStyleBackColor = False
        '
        'gpbAdd
        '
        Me.gpbAdd.Controls.Add(Me.txtEmail)
        Me.gpbAdd.Controls.Add(Me.txtCity)
        Me.gpbAdd.Controls.Add(Me.lbl9)
        Me.gpbAdd.Controls.Add(Me.lbl7)
        Me.gpbAdd.Controls.Add(Me.lbl6)
        Me.gpbAdd.Controls.Add(Me.lbl5)
        Me.gpbAdd.Controls.Add(Me.lbl4)
        Me.gpbAdd.Controls.Add(Me.Label3)
        Me.gpbAdd.Controls.Add(Me.lbl2)
        Me.gpbAdd.Controls.Add(Me.lbl1)
        Me.gpbAdd.Controls.Add(Me.cboStates)
        Me.gpbAdd.Controls.Add(Me.txtPhone)
        Me.gpbAdd.Controls.Add(Me.txtZip)
        Me.gpbAdd.Controls.Add(Me.txtAddress)
        Me.gpbAdd.Controls.Add(Me.txtLastName)
        Me.gpbAdd.Controls.Add(Me.txtFirstName)
        Me.gpbAdd.Location = New System.Drawing.Point(302, 46)
        Me.gpbAdd.Name = "gpbAdd"
        Me.gpbAdd.Size = New System.Drawing.Size(831, 910)
        Me.gpbAdd.TabIndex = 9
        Me.gpbAdd.TabStop = False
        Me.gpbAdd.Text = "Submit Passenger "
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(320, 721)
        Me.txtEmail.Margin = New System.Windows.Forms.Padding(7)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(228, 35)
        Me.txtEmail.TabIndex = 37
        '
        'txtCity
        '
        Me.txtCity.Location = New System.Drawing.Point(320, 351)
        Me.txtCity.Margin = New System.Windows.Forms.Padding(7)
        Me.txtCity.Name = "txtCity"
        Me.txtCity.Size = New System.Drawing.Size(228, 35)
        Me.txtCity.TabIndex = 36
        '
        'lbl9
        '
        Me.lbl9.AutoSize = True
        Me.lbl9.Location = New System.Drawing.Point(48, 721)
        Me.lbl9.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.lbl9.Name = "lbl9"
        Me.lbl9.Size = New System.Drawing.Size(80, 29)
        Me.lbl9.TabIndex = 35
        Me.lbl9.Text = "Email:"
        '
        'lbl7
        '
        Me.lbl7.AutoSize = True
        Me.lbl7.Location = New System.Drawing.Point(48, 637)
        Me.lbl7.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.lbl7.Name = "lbl7"
        Me.lbl7.Size = New System.Drawing.Size(182, 29)
        Me.lbl7.TabIndex = 33
        Me.lbl7.Text = "Phone Number:"
        '
        'lbl6
        '
        Me.lbl6.AutoSize = True
        Me.lbl6.Location = New System.Drawing.Point(48, 542)
        Me.lbl6.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.lbl6.Name = "lbl6"
        Me.lbl6.Size = New System.Drawing.Size(53, 29)
        Me.lbl6.TabIndex = 32
        Me.lbl6.Text = "Zip:"
        '
        'lbl5
        '
        Me.lbl5.AutoSize = True
        Me.lbl5.Location = New System.Drawing.Point(48, 444)
        Me.lbl5.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.lbl5.Name = "lbl5"
        Me.lbl5.Size = New System.Drawing.Size(74, 29)
        Me.lbl5.TabIndex = 31
        Me.lbl5.Text = "State:"
        '
        'lbl4
        '
        Me.lbl4.AutoSize = True
        Me.lbl4.Location = New System.Drawing.Point(48, 357)
        Me.lbl4.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.lbl4.Name = "lbl4"
        Me.lbl4.Size = New System.Drawing.Size(59, 29)
        Me.lbl4.TabIndex = 30
        Me.lbl4.Text = "City:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(48, 267)
        Me.Label3.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(108, 29)
        Me.Label3.TabIndex = 29
        Me.Label3.Text = "Address:"
        '
        'lbl2
        '
        Me.lbl2.AutoSize = True
        Me.lbl2.Location = New System.Drawing.Point(48, 173)
        Me.lbl2.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.lbl2.Name = "lbl2"
        Me.lbl2.Size = New System.Drawing.Size(134, 29)
        Me.lbl2.TabIndex = 28
        Me.lbl2.Text = "Last Name:"
        '
        'lbl1
        '
        Me.lbl1.AutoSize = True
        Me.lbl1.Location = New System.Drawing.Point(48, 78)
        Me.lbl1.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.lbl1.Name = "lbl1"
        Me.lbl1.Size = New System.Drawing.Size(137, 29)
        Me.lbl1.TabIndex = 27
        Me.lbl1.Text = "First Name:"
        '
        'cboStates
        '
        Me.cboStates.FormattingEnabled = True
        Me.cboStates.Location = New System.Drawing.Point(320, 437)
        Me.cboStates.Margin = New System.Windows.Forms.Padding(7)
        Me.cboStates.Name = "cboStates"
        Me.cboStates.Size = New System.Drawing.Size(277, 37)
        Me.cboStates.TabIndex = 24
        '
        'txtPhone
        '
        Me.txtPhone.Location = New System.Drawing.Point(320, 637)
        Me.txtPhone.Margin = New System.Windows.Forms.Padding(7)
        Me.txtPhone.Name = "txtPhone"
        Me.txtPhone.Size = New System.Drawing.Size(228, 35)
        Me.txtPhone.TabIndex = 22
        '
        'txtZip
        '
        Me.txtZip.Location = New System.Drawing.Point(320, 542)
        Me.txtZip.Margin = New System.Windows.Forms.Padding(7)
        Me.txtZip.Name = "txtZip"
        Me.txtZip.Size = New System.Drawing.Size(228, 35)
        Me.txtZip.TabIndex = 21
        '
        'txtAddress
        '
        Me.txtAddress.Location = New System.Drawing.Point(320, 252)
        Me.txtAddress.Margin = New System.Windows.Forms.Padding(7)
        Me.txtAddress.Name = "txtAddress"
        Me.txtAddress.Size = New System.Drawing.Size(228, 35)
        Me.txtAddress.TabIndex = 20
        '
        'txtLastName
        '
        Me.txtLastName.Location = New System.Drawing.Point(320, 158)
        Me.txtLastName.Margin = New System.Windows.Forms.Padding(7)
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(228, 35)
        Me.txtLastName.TabIndex = 19
        '
        'txtFirstName
        '
        Me.txtFirstName.Location = New System.Drawing.Point(320, 64)
        Me.txtFirstName.Margin = New System.Windows.Forms.Padding(7)
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(228, 35)
        Me.txtFirstName.TabIndex = 18
        '
        'frmAddPassenger
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(14.0!, 29.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1434, 1117)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnSubmit)
        Me.Controls.Add(Me.gpbAdd)
        Me.Name = "frmAddPassenger"
        Me.Text = "frmAddPassenger"
        Me.gpbAdd.ResumeLayout(False)
        Me.gpbAdd.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnExit As Button
    Friend WithEvents btnSubmit As Button
    Friend WithEvents gpbAdd As GroupBox
    Friend WithEvents txtEmail As TextBox
    Friend WithEvents txtCity As TextBox
    Friend WithEvents lbl9 As Label
    Friend WithEvents lbl7 As Label
    Friend WithEvents lbl6 As Label
    Friend WithEvents lbl5 As Label
    Friend WithEvents lbl4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents lbl2 As Label
    Friend WithEvents lbl1 As Label
    Friend WithEvents cboStates As ComboBox
    Friend WithEvents txtPhone As TextBox
    Friend WithEvents txtZip As TextBox
    Friend WithEvents txtAddress As TextBox
    Friend WithEvents txtLastName As TextBox
    Friend WithEvents txtFirstName As TextBox
End Class
