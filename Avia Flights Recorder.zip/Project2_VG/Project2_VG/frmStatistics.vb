﻿Public Class frmStatistics
    Private Sub frmStatistics_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Dim strSelect As String = ""
            Dim cmdSelect As OleDb.OleDbCommand            ' this will be used for our Select statement
            Dim strSelect2 As String = ""
            Dim cmdSelect2 As OleDb.OleDbCommand            ' this will be used for our Select statement
            Dim strSelect3 As String = ""
            Dim cmdSelect3 As OleDb.OleDbCommand            ' this will be used for our Select statement
            Dim strSelect4 As String = ""
            Dim cmdSelect4 As OleDb.OleDbCommand            ' this will be used for our Select statement
            Dim drSourceTable As OleDb.OleDbDataReader     ' this will be where our result set will 
            Dim strSelect5 As String = ""
            Dim cmdSelect5 As OleDb.OleDbCommand            ' this will be used for our Select statement

            Dim dt As DataTable = New DataTable            ' this is the table we will load from our reader


            ' open the DB
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()

            End If

            ' Build the select statement
            'strSelect = "SELECT Count(*) as TotalPassengers " &
            '            "FROM TPassengers as TP"

            'MessageBox.Show(strSelect)

            cmdSelect = New OleDb.OleDbCommand("prsPassengers", m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader

            ' Read result( highest ID )
            drSourceTable.Read()

            ' Null? (empty table)
            If drSourceTable.IsDBNull(0) = True Then

                ' Yes, start numbering at 1
                lblTotalNumberPassengers.Text = 0

            Else

                ' No, get the next highest ID
                lblTotalNumberPassengers.Text = CInt(drSourceTable("TotalPassengers"))

            End If

            'strSelect = "SELECT Count(TP.intPassengerID) as TotalPassengers " &
            '            "FROM TPassengers as TP "

            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand("upsPassengers", m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader

            ' Build the select statement
            strSelect2 = "SELECT COUNT(*) as TotalFlights " &
                         "FROM TFlightPassengers as TFP "

            'MessageBox.Show(strSelect2)

            cmdSelect2 = New OleDb.OleDbCommand(strSelect2, m_conAdministrator)
            drSourceTable = cmdSelect2.ExecuteReader

            ' Read result( highest ID )
            drSourceTable.Read()

            ' Null? (empty table)
            If drSourceTable.IsDBNull(0) = True Then

                ' Yes, start numbering at 1
                lblTotalFlightsPassengers.Text = 0

            Else

                ' No, get the next highest ID
                lblTotalFlightsPassengers.Text = CInt(drSourceTable("TotalFlights"))
            End If

            'strSelect2 = "SELECT Count(intFlightPassengerID) as TotalFlights" &
            '            "FROM TFlightPassengers"


            ' Retrieve all the records 
            cmdSelect3 = New OleDb.OleDbCommand("prsPassengerFlight", m_conAdministrator)
            drSourceTable = cmdSelect3.ExecuteReader

            '' Build the select statement
            'strSelect3 = "SELECT AVG(TF.intMilesFlown) as AvgMiles " &
            '            " From TFlights as TF Join TFlightPassengers as TFP " &
            '            " ON TF.intFlightID = TFP.intFlightID "

            'MessageBox.Show(strSelect3)

            'cmdSelect3 = New OleDb.OleDbCommand(strSelect3, m_conAdministrator)
            'drSourceTable = cmdSelect3.ExecuteReader

            ' Read result( highest ID )
            drSourceTable.Read()

            ' Null? (empty table)
            If drSourceTable.IsDBNull(0) = True Then

                ' Yes, start numbering at 1
                lblAvgMilesFlown.Text = 0

            Else

                ' No, get the next highest ID
                lblAvgMilesFlown.Text = (drSourceTable("TotalPassengers"))

            End If

            'strSelect3 = "SELECT AVG(TF.intMilesFlown) as AvgMiles  " &
            '            " FROM TFlights as TF Join TFlightPassengers as TFP " &
            '            " ON TF.intFlightID = TFP.intFlightID "
            ' Retrieve all the records 

            cmdSelect3 = New OleDb.OleDbCommand("prsAVGPassengerMiles", m_conAdministrator)
            drSourceTable = cmdSelect3.ExecuteReader

            ' Read result( highest ID )
            drSourceTable.Read()



            'strSelect4 = " Select TP.strFirstName, TP.strLastName, TF.intMilesFlown  " &
            '        " FROM TPilots as TP Join TPilotFlights as TPF " &
            '        " ON TP.intPilotID = TPF.intPilotID " &
            '        " Join TFlights as TF " &
            '        " ON TPF.intFlightID = TF.intFlightID " &
            '        " Order by TP.strLastName "

            'MessageBox.Show(strSelect4)

            cmdSelect4 = New OleDb.OleDbCommand("prsPilotMiles", m_conAdministrator)
            drSourceTable = cmdSelect4.ExecuteReader

            ' Read result( highest ID )
            drSourceTable.Read()

            'strSelect5 = "Select TA.strFirstName, TA.strLastName, TF.intMilesFlown " &
            '     " FROM TAttendants As TA JOIN TAttendantFlights As TAF " &
            '     " On TA.intAttendantID = TAF.intAttendantID " &
            '     " JOIN TFlights As TF " &
            '     " On TAF.intFlightID = TF.intFlightID" &
            '     " Order by TA.strLastName "

            'MessageBox.Show(strSelect)

            cmdSelect5 = New OleDb.OleDbCommand("prsAttendantMiles2", m_conAdministrator)
            drSourceTable = cmdSelect5.ExecuteReader

            ' Read result( highest ID )
            drSourceTable.Read()


            lstStatistics.Items.Add("Statistics")
            lstStatistics.Items.Add("  ")
            lstStatistics.Items.Add("=======================================")

            While drSourceTable.Read()

                lstStatistics.Items.Add("  ")

                lstStatistics.Items.Add("Pilot Name: " & vbTab & drSourceTable("TP.strFirstName") & " " & drSourceTable("TP.strLastName") & " " & drSourceTable("TF.intMilesFlown"))


                lstStatistics.Items.Add("Attendant Name: " & vbTab & drSourceTable("TA.strFirstName") & " " & drSourceTable("TA.strLastName") & " " & drSourceTable("TF.intMilesFlown"))


                lstStatistics.Items.Add("  ")
                lstStatistics.Items.Add("=======================================")

                lblTotalNumberPassengers.Text = drSourceTable("TotalPassengers")
                lblTotalFlightsPassengers.Text = drSourceTable("TotalFlights")
                lblAvgMilesFlown.Text = drSourceTable("AvgMiles")

            End While

            ' Clean up
            drSourceTable.Close()

            ' close the database connection
            CloseDatabaseConnection()

        Catch ex As Exception

            ' Log and display error message
            MessageBox.Show(ex.Message)

        End Try
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub

End Class