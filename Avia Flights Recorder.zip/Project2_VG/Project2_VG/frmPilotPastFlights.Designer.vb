﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPilotPastFlights
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblMiles = New System.Windows.Forms.Label()
        Me.lbl2 = New System.Windows.Forms.Label()
        Me.lstPilotPastFlight = New System.Windows.Forms.ListBox()
        Me.lblPilotName = New System.Windows.Forms.Label()
        Me.cboPilot = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(239, 783)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(199, 57)
        Me.btnExit.TabIndex = 21
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'lblMiles
        '
        Me.lblMiles.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.lblMiles.Location = New System.Drawing.Point(515, 217)
        Me.lblMiles.Name = "lblMiles"
        Me.lblMiles.Size = New System.Drawing.Size(504, 32)
        Me.lblMiles.TabIndex = 20
        '
        'lbl2
        '
        Me.lbl2.AutoSize = True
        Me.lbl2.Location = New System.Drawing.Point(234, 220)
        Me.lbl2.Name = "lbl2"
        Me.lbl2.Size = New System.Drawing.Size(89, 29)
        Me.lbl2.TabIndex = 19
        Me.lbl2.Text = "Miles : "
        '
        'lstPilotPastFlight
        '
        Me.lstPilotPastFlight.FormattingEnabled = True
        Me.lstPilotPastFlight.ItemHeight = 29
        Me.lstPilotPastFlight.Location = New System.Drawing.Point(234, 282)
        Me.lstPilotPastFlight.Margin = New System.Windows.Forms.Padding(1)
        Me.lstPilotPastFlight.Name = "lstPilotPastFlight"
        Me.lstPilotPastFlight.Size = New System.Drawing.Size(785, 352)
        Me.lstPilotPastFlight.TabIndex = 18
        '
        'lblPilotName
        '
        Me.lblPilotName.AutoSize = True
        Me.lblPilotName.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPilotName.Location = New System.Drawing.Point(228, 148)
        Me.lblPilotName.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lblPilotName.Name = "lblPilotName"
        Me.lblPilotName.Size = New System.Drawing.Size(178, 36)
        Me.lblPilotName.TabIndex = 17
        Me.lblPilotName.Text = "Pilot Name:"
        '
        'cboPilot
        '
        Me.cboPilot.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboPilot.FormattingEnabled = True
        Me.cboPilot.Location = New System.Drawing.Point(640, 148)
        Me.cboPilot.Margin = New System.Windows.Forms.Padding(1)
        Me.cboPilot.Name = "cboPilot"
        Me.cboPilot.Size = New System.Drawing.Size(379, 44)
        Me.cboPilot.TabIndex = 16
        '
        'frmPilotPastFlights
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(14.0!, 29.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1087, 989)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.lblMiles)
        Me.Controls.Add(Me.lbl2)
        Me.Controls.Add(Me.lstPilotPastFlight)
        Me.Controls.Add(Me.lblPilotName)
        Me.Controls.Add(Me.cboPilot)
        Me.Name = "frmPilotPastFlights"
        Me.Text = "frmPilotPastFlights"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnExit As Button
    Friend WithEvents lblMiles As Label
    Friend WithEvents lbl2 As Label
    Friend WithEvents lstPilotPastFlight As ListBox
    Friend WithEvents lblPilotName As Label
    Friend WithEvents cboPilot As ComboBox
End Class
