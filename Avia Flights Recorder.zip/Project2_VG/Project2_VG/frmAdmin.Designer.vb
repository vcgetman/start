﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAdmin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnSubmit = New System.Windows.Forms.Button()
        Me.gpbManagePilots = New System.Windows.Forms.GroupBox()
        Me.btnAddFlights = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnAddPilot = New System.Windows.Forms.Button()
        Me.gbxManageAttendants = New System.Windows.Forms.GroupBox()
        Me.btnAddAttendFlights = New System.Windows.Forms.Button()
        Me.btnDeleteAttendant = New System.Windows.Forms.Button()
        Me.btnAddAttendant = New System.Windows.Forms.Button()
        Me.gpbManagePilots.SuspendLayout()
        Me.gbxManageAttendants.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(401, 362)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(1)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(112, 32)
        Me.btnExit.TabIndex = 35
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'btnSubmit
        '
        Me.btnSubmit.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnSubmit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnSubmit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSubmit.Location = New System.Drawing.Point(241, 362)
        Me.btnSubmit.Margin = New System.Windows.Forms.Padding(1)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(112, 32)
        Me.btnSubmit.TabIndex = 34
        Me.btnSubmit.Text = "Submit"
        Me.btnSubmit.UseVisualStyleBackColor = False
        '
        'gpbManagePilots
        '
        Me.gpbManagePilots.Controls.Add(Me.btnAddFlights)
        Me.gpbManagePilots.Controls.Add(Me.btnDelete)
        Me.gpbManagePilots.Controls.Add(Me.btnAddPilot)
        Me.gpbManagePilots.Location = New System.Drawing.Point(79, 63)
        Me.gpbManagePilots.Margin = New System.Windows.Forms.Padding(1)
        Me.gpbManagePilots.Name = "gpbManagePilots"
        Me.gpbManagePilots.Padding = New System.Windows.Forms.Padding(1)
        Me.gpbManagePilots.Size = New System.Drawing.Size(253, 257)
        Me.gpbManagePilots.TabIndex = 33
        Me.gpbManagePilots.TabStop = False
        Me.gpbManagePilots.Text = "Manage Pilots: "
        '
        'btnAddFlights
        '
        Me.btnAddFlights.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnAddFlights.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnAddFlights.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddFlights.Location = New System.Drawing.Point(26, 164)
        Me.btnAddFlights.Margin = New System.Windows.Forms.Padding(1)
        Me.btnAddFlights.Name = "btnAddFlights"
        Me.btnAddFlights.Size = New System.Drawing.Size(217, 32)
        Me.btnAddFlights.TabIndex = 37
        Me.btnAddFlights.Text = "Add Pilot Future Flights"
        Me.btnAddFlights.UseVisualStyleBackColor = False
        '
        'btnDelete
        '
        Me.btnDelete.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnDelete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnDelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDelete.Location = New System.Drawing.Point(26, 105)
        Me.btnDelete.Margin = New System.Windows.Forms.Padding(1)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(217, 32)
        Me.btnDelete.TabIndex = 36
        Me.btnDelete.Text = "Delete Pilot"
        Me.btnDelete.UseVisualStyleBackColor = False
        '
        'btnAddPilot
        '
        Me.btnAddPilot.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnAddPilot.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnAddPilot.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddPilot.Location = New System.Drawing.Point(26, 41)
        Me.btnAddPilot.Margin = New System.Windows.Forms.Padding(1)
        Me.btnAddPilot.Name = "btnAddPilot"
        Me.btnAddPilot.Size = New System.Drawing.Size(217, 32)
        Me.btnAddPilot.TabIndex = 35
        Me.btnAddPilot.Text = "Add Pilot"
        Me.btnAddPilot.UseVisualStyleBackColor = False
        '
        'gbxManageAttendants
        '
        Me.gbxManageAttendants.Controls.Add(Me.btnAddAttendFlights)
        Me.gbxManageAttendants.Controls.Add(Me.btnDeleteAttendant)
        Me.gbxManageAttendants.Controls.Add(Me.btnAddAttendant)
        Me.gbxManageAttendants.Location = New System.Drawing.Point(417, 63)
        Me.gbxManageAttendants.Margin = New System.Windows.Forms.Padding(1)
        Me.gbxManageAttendants.Name = "gbxManageAttendants"
        Me.gbxManageAttendants.Padding = New System.Windows.Forms.Padding(1)
        Me.gbxManageAttendants.Size = New System.Drawing.Size(253, 257)
        Me.gbxManageAttendants.TabIndex = 36
        Me.gbxManageAttendants.TabStop = False
        Me.gbxManageAttendants.Text = "Manage Attendants: "
        '
        'btnAddAttendFlights
        '
        Me.btnAddAttendFlights.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnAddAttendFlights.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnAddAttendFlights.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddAttendFlights.Location = New System.Drawing.Point(26, 164)
        Me.btnAddAttendFlights.Margin = New System.Windows.Forms.Padding(1)
        Me.btnAddAttendFlights.Name = "btnAddAttendFlights"
        Me.btnAddAttendFlights.Size = New System.Drawing.Size(217, 32)
        Me.btnAddAttendFlights.TabIndex = 37
        Me.btnAddAttendFlights.Text = "Add Attendant Future Flights"
        Me.btnAddAttendFlights.UseVisualStyleBackColor = False
        '
        'btnDeleteAttendant
        '
        Me.btnDeleteAttendant.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnDeleteAttendant.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnDeleteAttendant.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDeleteAttendant.Location = New System.Drawing.Point(26, 105)
        Me.btnDeleteAttendant.Margin = New System.Windows.Forms.Padding(1)
        Me.btnDeleteAttendant.Name = "btnDeleteAttendant"
        Me.btnDeleteAttendant.Size = New System.Drawing.Size(217, 32)
        Me.btnDeleteAttendant.TabIndex = 36
        Me.btnDeleteAttendant.Text = "Delete Attendant"
        Me.btnDeleteAttendant.UseVisualStyleBackColor = False
        '
        'btnAddAttendant
        '
        Me.btnAddAttendant.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnAddAttendant.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnAddAttendant.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddAttendant.Location = New System.Drawing.Point(26, 41)
        Me.btnAddAttendant.Margin = New System.Windows.Forms.Padding(1)
        Me.btnAddAttendant.Name = "btnAddAttendant"
        Me.btnAddAttendant.Size = New System.Drawing.Size(217, 32)
        Me.btnAddAttendant.TabIndex = 35
        Me.btnAddAttendant.Text = "Add Attendant"
        Me.btnAddAttendant.UseVisualStyleBackColor = False
        '
        'frmAdmin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 495)
        Me.Controls.Add(Me.gbxManageAttendants)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnSubmit)
        Me.Controls.Add(Me.gpbManagePilots)
        Me.Name = "frmAdmin"
        Me.Text = "frmAdmin"
        Me.gpbManagePilots.ResumeLayout(False)
        Me.gbxManageAttendants.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnExit As Button
    Friend WithEvents btnSubmit As Button
    Friend WithEvents gpbManagePilots As GroupBox
    Friend WithEvents btnAddFlights As Button
    Friend WithEvents btnDelete As Button
    Friend WithEvents btnAddPilot As Button
    Friend WithEvents gbxManageAttendants As GroupBox
    Friend WithEvents btnAddAttendFlights As Button
    Friend WithEvents btnDeleteAttendant As Button
    Friend WithEvents btnAddAttendant As Button
End Class
