﻿Public Class frmPilotMain

    Private Sub frmPilots_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim strSelect As String = ""
        Dim cmdSelect As OleDb.OleDbCommand ' this will be used for our Select statement
        Dim drSourceTable As OleDb.OleDbDataReader ' this will be where our data is retrieved to
        Dim dtPilots As DataTable = New DataTable ' this is the table we will load from our reader


        Try


            ' open the DB this is in module
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                "The application will now close.",
                                Me.Text + " Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()

            End If


            ' Build the select statement to obtain Pilots
            strSelect = "SELECT intPilotID, strLastName FROM TPilots"

            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader
            dtPilots.Load(drSourceTable)

            'load the Last Name result set into the combobox.  For VB, we do this by binding the data to the combobox

            cboPilot.ValueMember = "intPilotID"
            cboPilot.DisplayMember = "strLastName"
            cboPilot.DataSource = dtPilots


            ' Clean up
            drSourceTable.Close()

            ' close the database connection
            CloseDatabaseConnection()

        Catch excError As Exception

            ' Log and display error message
            MessageBox.Show(excError.Message)

        End Try
    End Sub

    Private Sub btnDeletetePilot_Click(sender As Object, e As EventArgs) Handles btnDeletePilot.Click
        Dim frmDeletePilot As New frmDeleatePilot

        frmDeletePilot.ShowDialog()
    End Sub
    Private Sub btnAddPilot_Click(sender As Object, e As EventArgs) Handles btnAddPilot.Click
        Dim frmAddPilot As New frmAddPilot

        frmAddPilot.ShowDialog()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub

    Private Sub btnUpdatePilot_Click(sender As Object, e As EventArgs) Handles btnUpdatePilot.Click
        Dim frmUpdatePilot2 As New frmUpdatePilot2

        frmUpdatePilot2.ShowDialog()
    End Sub

    Private Sub btnShowPastFlights_Click(sender As Object, e As EventArgs) Handles btnShowPastFlights.Click
        Dim frmPilotPastFlights As New frmPilotPastFlights

        frmPilotPastFlights.ShowDialog()
    End Sub

    Private Sub btnShowFutureFlights_Click(sender As Object, e As EventArgs) Handles btnShowFutureFlights.Click
        Dim frmPilotFutureFlights As New frmPilotFutureFlights

        frmPilotFutureFlights.ShowDialog()
    End Sub


End Class