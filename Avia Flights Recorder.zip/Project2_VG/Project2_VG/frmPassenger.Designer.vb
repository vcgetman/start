﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmPassenger
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.cboPassenger = New System.Windows.Forms.ComboBox()
        Me.lblPasName = New System.Windows.Forms.Label()
        Me.btnAddPassenger = New System.Windows.Forms.Button()
        Me.btnUpdatePassenger = New System.Windows.Forms.Button()
        Me.btnAddPassengerFlight = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnShowPastFlights = New System.Windows.Forms.Button()
        Me.btnShowFutureFlights = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'cboPassenger
        '
        Me.cboPassenger.FormattingEnabled = True
        Me.cboPassenger.Location = New System.Drawing.Point(175, 16)
        Me.cboPassenger.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.cboPassenger.Name = "cboPassenger"
        Me.cboPassenger.Size = New System.Drawing.Size(275, 21)
        Me.cboPassenger.TabIndex = 0
        '
        'lblPasName
        '
        Me.lblPasName.Font = New System.Drawing.Font("Arial Rounded MT Bold", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPasName.Location = New System.Drawing.Point(13, 16)
        Me.lblPasName.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblPasName.Name = "lblPasName"
        Me.lblPasName.Size = New System.Drawing.Size(143, 21)
        Me.lblPasName.TabIndex = 2
        Me.lblPasName.Text = "Passenger Name : "
        '
        'btnAddPassenger
        '
        Me.btnAddPassenger.Font = New System.Drawing.Font("Arial Rounded MT Bold", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddPassenger.Location = New System.Drawing.Point(169, 60)
        Me.btnAddPassenger.Margin = New System.Windows.Forms.Padding(2, 1, 2, 1)
        Me.btnAddPassenger.Name = "btnAddPassenger"
        Me.btnAddPassenger.Size = New System.Drawing.Size(107, 36)
        Me.btnAddPassenger.TabIndex = 3
        Me.btnAddPassenger.Text = "Add New Passenger"
        Me.btnAddPassenger.UseVisualStyleBackColor = True
        '
        'btnUpdatePassenger
        '
        Me.btnUpdatePassenger.Font = New System.Drawing.Font("Arial Rounded MT Bold", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUpdatePassenger.Location = New System.Drawing.Point(16, 60)
        Me.btnUpdatePassenger.Margin = New System.Windows.Forms.Padding(2, 1, 2, 1)
        Me.btnUpdatePassenger.Name = "btnUpdatePassenger"
        Me.btnUpdatePassenger.Size = New System.Drawing.Size(107, 36)
        Me.btnUpdatePassenger.TabIndex = 4
        Me.btnUpdatePassenger.Text = "Update Passenger"
        Me.btnUpdatePassenger.UseVisualStyleBackColor = True
        '
        'btnAddPassengerFlight
        '
        Me.btnAddPassengerFlight.Font = New System.Drawing.Font("Arial Rounded MT Bold", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddPassengerFlight.Location = New System.Drawing.Point(323, 60)
        Me.btnAddPassengerFlight.Margin = New System.Windows.Forms.Padding(2, 1, 2, 1)
        Me.btnAddPassengerFlight.Name = "btnAddPassengerFlight"
        Me.btnAddPassengerFlight.Size = New System.Drawing.Size(107, 36)
        Me.btnAddPassengerFlight.TabIndex = 5
        Me.btnAddPassengerFlight.Text = "Add Flight"
        Me.btnAddPassengerFlight.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnExit.Font = New System.Drawing.Font("Arial Rounded MT Bold", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(169, 201)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(2, 1, 2, 1)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(107, 36)
        Me.btnExit.TabIndex = 6
        Me.btnExit.Text = "EXIT"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'btnShowPastFlights
        '
        Me.btnShowPastFlights.Font = New System.Drawing.Font("Arial Rounded MT Bold", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnShowPastFlights.Location = New System.Drawing.Point(89, 124)
        Me.btnShowPastFlights.Margin = New System.Windows.Forms.Padding(2, 1, 2, 1)
        Me.btnShowPastFlights.Name = "btnShowPastFlights"
        Me.btnShowPastFlights.Size = New System.Drawing.Size(107, 36)
        Me.btnShowPastFlights.TabIndex = 7
        Me.btnShowPastFlights.Text = "Show Past Flights"
        Me.btnShowPastFlights.UseVisualStyleBackColor = True
        '
        'btnShowFutureFlights
        '
        Me.btnShowFutureFlights.Font = New System.Drawing.Font("Arial Rounded MT Bold", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnShowFutureFlights.Location = New System.Drawing.Point(242, 124)
        Me.btnShowFutureFlights.Margin = New System.Windows.Forms.Padding(2, 1, 2, 1)
        Me.btnShowFutureFlights.Name = "btnShowFutureFlights"
        Me.btnShowFutureFlights.Size = New System.Drawing.Size(107, 36)
        Me.btnShowFutureFlights.TabIndex = 8
        Me.btnShowFutureFlights.Text = "Show Future Flights"
        Me.btnShowFutureFlights.UseVisualStyleBackColor = True
        '
        'frmPassenger
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(502, 284)
        Me.Controls.Add(Me.btnShowFutureFlights)
        Me.Controls.Add(Me.btnShowPastFlights)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnAddPassengerFlight)
        Me.Controls.Add(Me.btnUpdatePassenger)
        Me.Controls.Add(Me.btnAddPassenger)
        Me.Controls.Add(Me.lblPasName)
        Me.Controls.Add(Me.cboPassenger)
        Me.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.Name = "frmPassenger"
        Me.Text = "frmPassenger"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents cboPassenger As ComboBox
    Friend WithEvents lblPasName As Label
    Friend WithEvents btnAddPassenger As Button
    Friend WithEvents btnUpdatePassenger As Button
    Friend WithEvents btnAddPassengerFlight As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents btnShowPastFlights As Button
    Friend WithEvents btnShowFutureFlights As Button
End Class
