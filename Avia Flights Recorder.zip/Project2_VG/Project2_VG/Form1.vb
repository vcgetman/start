﻿Public Class Form1
    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        Dim frmPassenger As New frmPassenger
        Dim frmPilotMain As New frmPilotMain
        Dim frmAttendant As New frmAttendant
        Dim frmAdmin As New frmAdmin
        If cboUser.Text = "Passenger" Then
            frmPassenger.ShowDialog()
        End If

        If cboUser.Text = "Pilot" Then
            frmPilotMain.ShowDialog()
        End If
        If cboUser.Text = "Attendant" Then
            frmAttendant.ShowDialog()
        End If
        If cboUser.Text = "Administration" Then
            frmAdmin.ShowDialog()
        End If
    End Sub

    Private Sub btnStatistics_Click(sender As Object, e As EventArgs)
        Dim frmStatistics As New frmStatistics

        frmStatistics.ShowDialog()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub


End Class
