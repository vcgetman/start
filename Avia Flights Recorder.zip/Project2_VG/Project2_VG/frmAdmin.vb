﻿Public Class frmAdmin
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Dim frmDeletePilot As New frmDeleatePilot

        frmDeleatePilot.ShowDialog()
    End Sub

    Private Sub frmAdmin_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnAddPilot_Click(sender As Object, e As EventArgs) Handles btnAddPilot.Click
        Dim frmAddPilot As New frmAddPilot

        frmAddPilot.ShowDialog()
    End Sub

    Private Sub btnAddAttendant_Click(sender As Object, e As EventArgs) Handles btnAddAttendant.Click
        Dim frmAddAttendant As New frmAddAttendant

        frmAddAttendant.ShowDialog()
    End Sub

    Private Sub btnDeleteAttendant_Click(sender As Object, e As EventArgs) Handles btnDeleteAttendant.Click
        Dim frmDeleteAttendant As New frmDeleteAttendant

        frmDeleteAttendant.ShowDialog()
    End Sub
    Private Sub btnAddPilotFlight_Click(sender As Object, e As EventArgs) Handles btnAddFlights.Click
        Dim frmAddPilotFlight As New frmAddPilotFlight

        frmAddPilotFlight.ShowDialog()
    End Sub

    Private Sub btnAddAttendFlights_Click(sender As Object, e As EventArgs) Handles btnAddAttendFlights.Click
        Dim frmAddAttendantFlight As New frmAddAttendantFlight

        frmAddAttendantFlight.ShowDialog()
    End Sub
End Class