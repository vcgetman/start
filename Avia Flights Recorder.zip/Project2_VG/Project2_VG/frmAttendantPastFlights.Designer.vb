﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAttendantPastFlights
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblMiles = New System.Windows.Forms.Label()
        Me.lbl2 = New System.Windows.Forms.Label()
        Me.lstAttendantPastFlight = New System.Windows.Forms.ListBox()
        Me.lblAttendantName = New System.Windows.Forms.Label()
        Me.cboAttendant = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(62, 329)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(1)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(85, 26)
        Me.btnExit.TabIndex = 27
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'lblMiles
        '
        Me.lblMiles.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.lblMiles.Location = New System.Drawing.Point(181, 75)
        Me.lblMiles.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lblMiles.Name = "lblMiles"
        Me.lblMiles.Size = New System.Drawing.Size(216, 14)
        Me.lblMiles.TabIndex = 26
        '
        'lbl2
        '
        Me.lbl2.AutoSize = True
        Me.lbl2.Location = New System.Drawing.Point(60, 77)
        Me.lbl2.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lbl2.Name = "lbl2"
        Me.lbl2.Size = New System.Drawing.Size(40, 13)
        Me.lbl2.TabIndex = 25
        Me.lbl2.Text = "Miles : "
        '
        'lstAttendantPastFlight
        '
        Me.lstAttendantPastFlight.FormattingEnabled = True
        Me.lstAttendantPastFlight.Location = New System.Drawing.Point(60, 104)
        Me.lstAttendantPastFlight.Margin = New System.Windows.Forms.Padding(0)
        Me.lstAttendantPastFlight.Name = "lstAttendantPastFlight"
        Me.lstAttendantPastFlight.Size = New System.Drawing.Size(339, 160)
        Me.lstAttendantPastFlight.TabIndex = 24
        '
        'lblAttendantName
        '
        Me.lblAttendantName.AutoSize = True
        Me.lblAttendantName.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAttendantName.Location = New System.Drawing.Point(58, 44)
        Me.lblAttendantName.Margin = New System.Windows.Forms.Padding(0)
        Me.lblAttendantName.Name = "lblAttendantName"
        Me.lblAttendantName.Size = New System.Drawing.Size(251, 36)
        Me.lblAttendantName.TabIndex = 23
        Me.lblAttendantName.Text = "Attendant Name:"
        '
        'cboAttendant
        '
        Me.cboAttendant.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboAttendant.FormattingEnabled = True
        Me.cboAttendant.Location = New System.Drawing.Point(234, 44)
        Me.cboAttendant.Margin = New System.Windows.Forms.Padding(0)
        Me.cboAttendant.Name = "cboAttendant"
        Me.cboAttendant.Size = New System.Drawing.Size(165, 44)
        Me.cboAttendant.TabIndex = 22
        '
        'frmAttendantPastFlights
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(512, 433)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.lblMiles)
        Me.Controls.Add(Me.lbl2)
        Me.Controls.Add(Me.lstAttendantPastFlight)
        Me.Controls.Add(Me.lblAttendantName)
        Me.Controls.Add(Me.cboAttendant)
        Me.Name = "frmAttendantPastFlights"
        Me.Text = "frmAttendantPastFlights"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnExit As Button
    Friend WithEvents lblMiles As Label
    Friend WithEvents lbl2 As Label
    Friend WithEvents lstAttendantPastFlight As ListBox
    Friend WithEvents lblAttendantName As Label
    Friend WithEvents cboAttendant As ComboBox
End Class
