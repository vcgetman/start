﻿Public Class frmFutureFlight
    Private Sub frmFutureFlight_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim strSelect As String = ""
        Dim cmdSelect As OleDb.OleDbCommand ' this will be used for our Select statement
        Dim drSourceTable As OleDb.OleDbDataReader ' this will be where our data is retrieved to
        Dim dtPassenger As DataTable = New DataTable ' this is the table we will load from our reader


        Try


            ' open the DB this is in module
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                "The application will now close.",
                                Me.Text + " Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()

            End If


            ' Build the select statement to obtain Passengers
            strSelect = "SELECT intPassengerID, strLastName FROM TPassengers"

            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader
            dtPassenger.Load(drSourceTable)

            'load the Last Name result set into the combobox.  For VB, we do this by binding the data to the combobox

            cboPassenger.ValueMember = "intPassengerID"
            cboPassenger.DisplayMember = "strLastName"
            cboPassenger.DataSource = dtPassenger


            ' Clean up
            drSourceTable.Close()

            ' close the database connection
            CloseDatabaseConnection()

        Catch excError As Exception

            ' Log and display error message
            MessageBox.Show(excError.Message)

        End Try
    End Sub

    Private Sub cboPilot_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboPassenger.SelectedIndexChanged
        Dim strSelect As String = ""
        Dim strLastName As String = ""
        Dim cmdSelect As OleDb.OleDbCommand ' this will be used for our Select statement
        Dim drSourceTable As OleDb.OleDbDataReader ' this will be where our data is retrieved to
        Dim dtPassenger As DataTable = New DataTable ' this is the table we will load from our reader


        Try


            ' open the database this is in module
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()

            End If

            ' Build the select statement using PK from name selected
            strSelect = (" SELECT TP.intPassengerID, TF.strFlightNumber, TF.dtmFlightDate, TF.dtmTimeofDeparture, TF.dtmTimeOfLanding, TF.intMilesFlown " +
                        " FROM TPassengers as TP Join TFlightPassengers as TPF " +
                        " On TP.intPassengerID = TPF.intPassengerID " +
                        " Join TFlights as TF " +
                        " On TPF.intFlightID = TF.intFlightID " +
                        " Where TP.intPassengerID = " & cboPassenger.SelectedValue)
            '+ " Where TF.dtmFlightDate <= " & ("'4/1/2023'")


            'MessageBox.Show(strSelect)

            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader



            lstPassengerPastFlight.Items.Clear()


            ' populate the text boxes with the data
            lstPassengerPastFlight.Items.Add("=============================")


            While drSourceTable.Read()

                lstPassengerPastFlight.Items.Add("  ")

                lstPassengerPastFlight.Items.Add("Flight Number: " & vbTab & drSourceTable("strFlightNumber"))
                lstPassengerPastFlight.Items.Add("Flight Date : " & vbTab & drSourceTable("dtmFlightDate"))
                lstPassengerPastFlight.Items.Add("Departure Time: " & vbTab & drSourceTable("dtmTimeofDeparture"))
                lstPassengerPastFlight.Items.Add("Arrival Time : " & vbTab & drSourceTable("dtmTimeOfLanding"))
                lstPassengerPastFlight.Items.Add("Miles Flown : " & vbTab & drSourceTable("intMilesFlown"))

                lstPassengerPastFlight.Items.Add("  ")
                lstPassengerPastFlight.Items.Add("=============================")

                lblMiles.Text = CInt(drSourceTable("intMilesFlown"))

            End While


            ' close the database connection
            CloseDatabaseConnection()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try


        'End While



    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub

    Private Sub lblMiles_Click(sender As Object, e As EventArgs) Handles lblMiles.Click

        Try

            Dim strSelect As String = ""
            Dim cmdSelect As OleDb.OleDbCommand            ' this will be used for our Select statement
            Dim drSourceTable As OleDb.OleDbDataReader     ' this will be where our result set will 
            Dim dt As DataTable = New DataTable            ' this is the table we will load from our reader


            ' open the DB
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()

            End If

            ' Build the select statement
            strSelect = "SELECT intMilesFlown as MilesFlown " &
                        "FROM TFlifgts as TF"

            'MessageBox.Show(strSelect)

            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader

            ' Read result( highest ID )
            drSourceTable.Read()

            ' Null? (empty table)
            If drSourceTable.IsDBNull(0) = True Then

                ' Yes, start numbering at 1
                lblMiles.Text = 0

            Else

                ' No, get the next highest ID
                lblMiles.Text = CInt(drSourceTable("intMilesFlown"))

            End If


            strSelect = "Select TF.intMilesFlown as intMilesFlown " &
                        " from TFlights as TF Join TFlightPassengers as TPF " &
                        " On TF.intFlightID = TPF.intFlightID Join TPassengers as TP " &
                        " ON TP.intPassengerID = TPF.intPassengerID" &
                        " Group By TP.strFirstName, TP.strLastName "

            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader



            ' Clean up
            drSourceTable.Close()

            ' close the database connection
            CloseDatabaseConnection()

        Catch ex As Exception

            ' Log and display error message
            MessageBox.Show(ex.Message)

        End Try
    End Sub
End Class