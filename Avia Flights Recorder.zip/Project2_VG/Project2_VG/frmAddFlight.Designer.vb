﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAddFlight
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnSelect = New System.Windows.Forms.Button()
        Me.gpbAdd = New System.Windows.Forms.GroupBox()
        Me.cboToAirport = New System.Windows.Forms.ComboBox()
        Me.txtArrTime = New System.Windows.Forms.TextBox()
        Me.lbl9 = New System.Windows.Forms.Label()
        Me.lbl7 = New System.Windows.Forms.Label()
        Me.lbl6 = New System.Windows.Forms.Label()
        Me.lbl5 = New System.Windows.Forms.Label()
        Me.lbl4 = New System.Windows.Forms.Label()
        Me.lbl3 = New System.Windows.Forms.Label()
        Me.lbl2 = New System.Windows.Forms.Label()
        Me.lbl1 = New System.Windows.Forms.Label()
        Me.cboFromAirport = New System.Windows.Forms.ComboBox()
        Me.txtDepTime = New System.Windows.Forms.TextBox()
        Me.txtFlightNumber = New System.Windows.Forms.TextBox()
        Me.txtFlightDate = New System.Windows.Forms.TextBox()
        Me.cboSelectFlight = New System.Windows.Forms.ComboBox()
        Me.lbl10 = New System.Windows.Forms.Label()
        Me.cboPlane = New System.Windows.Forms.ComboBox()
        Me.cboMiles = New System.Windows.Forms.ComboBox()
        Me.gpbAdd.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(624, 1002)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(262, 71)
        Me.btnExit.TabIndex = 14
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'btnSelect
        '
        Me.btnSelect.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnSelect.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnSelect.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSelect.Location = New System.Drawing.Point(196, 1002)
        Me.btnSelect.Name = "btnSelect"
        Me.btnSelect.Size = New System.Drawing.Size(262, 71)
        Me.btnSelect.TabIndex = 13
        Me.btnSelect.Text = "Select"
        Me.btnSelect.UseVisualStyleBackColor = False
        '
        'gpbAdd
        '
        Me.gpbAdd.Controls.Add(Me.cboMiles)
        Me.gpbAdd.Controls.Add(Me.cboPlane)
        Me.gpbAdd.Controls.Add(Me.cboToAirport)
        Me.gpbAdd.Controls.Add(Me.txtArrTime)
        Me.gpbAdd.Controls.Add(Me.lbl9)
        Me.gpbAdd.Controls.Add(Me.lbl7)
        Me.gpbAdd.Controls.Add(Me.lbl6)
        Me.gpbAdd.Controls.Add(Me.lbl5)
        Me.gpbAdd.Controls.Add(Me.lbl4)
        Me.gpbAdd.Controls.Add(Me.lbl3)
        Me.gpbAdd.Controls.Add(Me.lbl2)
        Me.gpbAdd.Controls.Add(Me.lbl1)
        Me.gpbAdd.Controls.Add(Me.cboFromAirport)
        Me.gpbAdd.Controls.Add(Me.txtDepTime)
        Me.gpbAdd.Controls.Add(Me.txtFlightNumber)
        Me.gpbAdd.Controls.Add(Me.txtFlightDate)
        Me.gpbAdd.Location = New System.Drawing.Point(196, 117)
        Me.gpbAdd.Name = "gpbAdd"
        Me.gpbAdd.Size = New System.Drawing.Size(831, 842)
        Me.gpbAdd.TabIndex = 12
        Me.gpbAdd.TabStop = False
        Me.gpbAdd.Text = "Select Flight"
        '
        'cboToAirport
        '
        Me.cboToAirport.FormattingEnabled = True
        Me.cboToAirport.Location = New System.Drawing.Point(320, 522)
        Me.cboToAirport.Margin = New System.Windows.Forms.Padding(7)
        Me.cboToAirport.Name = "cboToAirport"
        Me.cboToAirport.Size = New System.Drawing.Size(277, 37)
        Me.cboToAirport.TabIndex = 38
        '
        'txtArrTime
        '
        Me.txtArrTime.Location = New System.Drawing.Point(320, 351)
        Me.txtArrTime.Margin = New System.Windows.Forms.Padding(7)
        Me.txtArrTime.Name = "txtArrTime"
        Me.txtArrTime.Size = New System.Drawing.Size(228, 35)
        Me.txtArrTime.TabIndex = 36
        '
        'lbl9
        '
        Me.lbl9.AutoSize = True
        Me.lbl9.Location = New System.Drawing.Point(48, 721)
        Me.lbl9.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.lbl9.Name = "lbl9"
        Me.lbl9.Size = New System.Drawing.Size(75, 29)
        Me.lbl9.TabIndex = 35
        Me.lbl9.Text = "Plane"
        '
        'lbl7
        '
        Me.lbl7.AutoSize = True
        Me.lbl7.Location = New System.Drawing.Point(48, 637)
        Me.lbl7.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.lbl7.Name = "lbl7"
        Me.lbl7.Size = New System.Drawing.Size(71, 29)
        Me.lbl7.TabIndex = 33
        Me.lbl7.Text = "Miles"
        '
        'lbl6
        '
        Me.lbl6.AutoSize = True
        Me.lbl6.Location = New System.Drawing.Point(48, 542)
        Me.lbl6.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.lbl6.Name = "lbl6"
        Me.lbl6.Size = New System.Drawing.Size(120, 29)
        Me.lbl6.TabIndex = 32
        Me.lbl6.Text = "To Airport"
        '
        'lbl5
        '
        Me.lbl5.AutoSize = True
        Me.lbl5.Location = New System.Drawing.Point(48, 444)
        Me.lbl5.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.lbl5.Name = "lbl5"
        Me.lbl5.Size = New System.Drawing.Size(147, 29)
        Me.lbl5.TabIndex = 31
        Me.lbl5.Text = "From Airport"
        '
        'lbl4
        '
        Me.lbl4.AutoSize = True
        Me.lbl4.Location = New System.Drawing.Point(48, 357)
        Me.lbl4.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.lbl4.Name = "lbl4"
        Me.lbl4.Size = New System.Drawing.Size(142, 29)
        Me.lbl4.TabIndex = 30
        Me.lbl4.Text = "Arrival Time"
        '
        'lbl3
        '
        Me.lbl3.AutoSize = True
        Me.lbl3.Location = New System.Drawing.Point(48, 267)
        Me.lbl3.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.lbl3.Name = "lbl3"
        Me.lbl3.Size = New System.Drawing.Size(182, 29)
        Me.lbl3.TabIndex = 29
        Me.lbl3.Text = "Departure Time"
        '
        'lbl2
        '
        Me.lbl2.AutoSize = True
        Me.lbl2.Location = New System.Drawing.Point(48, 173)
        Me.lbl2.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.lbl2.Name = "lbl2"
        Me.lbl2.Size = New System.Drawing.Size(166, 29)
        Me.lbl2.TabIndex = 28
        Me.lbl2.Text = "Flight Number"
        '
        'lbl1
        '
        Me.lbl1.AutoSize = True
        Me.lbl1.Location = New System.Drawing.Point(48, 78)
        Me.lbl1.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.lbl1.Name = "lbl1"
        Me.lbl1.Size = New System.Drawing.Size(129, 29)
        Me.lbl1.TabIndex = 27
        Me.lbl1.Text = "Flight Date"
        '
        'cboFromAirport
        '
        Me.cboFromAirport.FormattingEnabled = True
        Me.cboFromAirport.Location = New System.Drawing.Point(320, 437)
        Me.cboFromAirport.Margin = New System.Windows.Forms.Padding(7)
        Me.cboFromAirport.Name = "cboFromAirport"
        Me.cboFromAirport.Size = New System.Drawing.Size(277, 37)
        Me.cboFromAirport.TabIndex = 24
        '
        'txtDepTime
        '
        Me.txtDepTime.Location = New System.Drawing.Point(320, 252)
        Me.txtDepTime.Margin = New System.Windows.Forms.Padding(7)
        Me.txtDepTime.Name = "txtDepTime"
        Me.txtDepTime.Size = New System.Drawing.Size(228, 35)
        Me.txtDepTime.TabIndex = 20
        '
        'txtFlightNumber
        '
        Me.txtFlightNumber.Location = New System.Drawing.Point(320, 158)
        Me.txtFlightNumber.Margin = New System.Windows.Forms.Padding(7)
        Me.txtFlightNumber.Name = "txtFlightNumber"
        Me.txtFlightNumber.Size = New System.Drawing.Size(228, 35)
        Me.txtFlightNumber.TabIndex = 19
        '
        'txtFlightDate
        '
        Me.txtFlightDate.Location = New System.Drawing.Point(320, 64)
        Me.txtFlightDate.Margin = New System.Windows.Forms.Padding(7)
        Me.txtFlightDate.Name = "txtFlightDate"
        Me.txtFlightDate.Size = New System.Drawing.Size(228, 35)
        Me.txtFlightDate.TabIndex = 18
        '
        'cboSelectFlight
        '
        Me.cboSelectFlight.FormattingEnabled = True
        Me.cboSelectFlight.Location = New System.Drawing.Point(490, 54)
        Me.cboSelectFlight.Name = "cboSelectFlight"
        Me.cboSelectFlight.Size = New System.Drawing.Size(568, 37)
        Me.cboSelectFlight.TabIndex = 36
        '
        'lbl10
        '
        Me.lbl10.AutoSize = True
        Me.lbl10.Location = New System.Drawing.Point(107, 54)
        Me.lbl10.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.lbl10.Name = "lbl10"
        Me.lbl10.Size = New System.Drawing.Size(153, 29)
        Me.lbl10.TabIndex = 35
        Me.lbl10.Text = "Select Flight:"
        '
        'cboPlane
        '
        Me.cboPlane.FormattingEnabled = True
        Me.cboPlane.Location = New System.Drawing.Point(320, 718)
        Me.cboPlane.Margin = New System.Windows.Forms.Padding(7)
        Me.cboPlane.Name = "cboPlane"
        Me.cboPlane.Size = New System.Drawing.Size(277, 37)
        Me.cboPlane.TabIndex = 39
        '
        'cboMiles
        '
        Me.cboMiles.FormattingEnabled = True
        Me.cboMiles.Location = New System.Drawing.Point(320, 629)
        Me.cboMiles.Margin = New System.Windows.Forms.Padding(7)
        Me.cboMiles.Name = "cboMiles"
        Me.cboMiles.Size = New System.Drawing.Size(277, 37)
        Me.cboMiles.TabIndex = 40
        '
        'frmAddFlight
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(14.0!, 29.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1222, 1122)
        Me.Controls.Add(Me.cboSelectFlight)
        Me.Controls.Add(Me.lbl10)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnSelect)
        Me.Controls.Add(Me.gpbAdd)
        Me.Name = "frmAddFlight"
        Me.Text = "frmAddFlight"
        Me.gpbAdd.ResumeLayout(False)
        Me.gpbAdd.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnExit As Button
    Friend WithEvents btnSelect As Button
    Friend WithEvents gpbAdd As GroupBox
    Friend WithEvents txtArrTime As TextBox
    Friend WithEvents lbl9 As Label
    Friend WithEvents lbl7 As Label
    Friend WithEvents lbl6 As Label
    Friend WithEvents lbl5 As Label
    Friend WithEvents lbl4 As Label
    Friend WithEvents lbl3 As Label
    Friend WithEvents lbl2 As Label
    Friend WithEvents lbl1 As Label
    Friend WithEvents cboFromAirport As ComboBox
    Friend WithEvents txtDepTime As TextBox
    Friend WithEvents txtFlightNumber As TextBox
    Friend WithEvents txtFlightDate As TextBox
    Friend WithEvents cboToAirport As ComboBox
    Friend WithEvents cboSelectFlight As ComboBox
    Friend WithEvents lbl10 As Label
    Friend WithEvents cboPlane As ComboBox
    Friend WithEvents cboMiles As ComboBox
End Class
