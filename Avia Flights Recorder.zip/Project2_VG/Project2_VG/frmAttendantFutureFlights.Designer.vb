﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAttendantFutureFlights
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblMiles = New System.Windows.Forms.Label()
        Me.lbl2 = New System.Windows.Forms.Label()
        Me.lstFutureFlight = New System.Windows.Forms.ListBox()
        Me.lblName = New System.Windows.Forms.Label()
        Me.cboAttendant = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(53, 321)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(1)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(85, 26)
        Me.btnExit.TabIndex = 33
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'lblMiles
        '
        Me.lblMiles.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.lblMiles.Location = New System.Drawing.Point(171, 67)
        Me.lblMiles.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lblMiles.Name = "lblMiles"
        Me.lblMiles.Size = New System.Drawing.Size(216, 14)
        Me.lblMiles.TabIndex = 32
        '
        'lbl2
        '
        Me.lbl2.AutoSize = True
        Me.lbl2.Location = New System.Drawing.Point(51, 68)
        Me.lbl2.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lbl2.Name = "lbl2"
        Me.lbl2.Size = New System.Drawing.Size(40, 13)
        Me.lbl2.TabIndex = 31
        Me.lbl2.Text = "Miles : "
        '
        'lstFutureFlight
        '
        Me.lstFutureFlight.FormattingEnabled = True
        Me.lstFutureFlight.Location = New System.Drawing.Point(51, 96)
        Me.lstFutureFlight.Margin = New System.Windows.Forms.Padding(0)
        Me.lstFutureFlight.Name = "lstFutureFlight"
        Me.lstFutureFlight.Size = New System.Drawing.Size(339, 160)
        Me.lstFutureFlight.TabIndex = 30
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblName.Location = New System.Drawing.Point(48, 36)
        Me.lblName.Margin = New System.Windows.Forms.Padding(0)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(251, 36)
        Me.lblName.TabIndex = 29
        Me.lblName.Text = "Attendant Name:"
        '
        'cboAttendant
        '
        Me.cboAttendant.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboAttendant.FormattingEnabled = True
        Me.cboAttendant.Location = New System.Drawing.Point(225, 36)
        Me.cboAttendant.Margin = New System.Windows.Forms.Padding(0)
        Me.cboAttendant.Name = "cboAttendant"
        Me.cboAttendant.Size = New System.Drawing.Size(165, 44)
        Me.cboAttendant.TabIndex = 28
        '
        'frmAttendantFutureFlights
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(456, 436)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.lblMiles)
        Me.Controls.Add(Me.lbl2)
        Me.Controls.Add(Me.lstFutureFlight)
        Me.Controls.Add(Me.lblName)
        Me.Controls.Add(Me.cboAttendant)
        Me.Name = "frmAttendantFutureFlights"
        Me.Text = "frmAttendantFutureFlights"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnExit As Button
    Friend WithEvents lblMiles As Label
    Friend WithEvents lbl2 As Label
    Friend WithEvents lstFutureFlight As ListBox
    Friend WithEvents lblName As Label
    Friend WithEvents cboAttendant As ComboBox
End Class
