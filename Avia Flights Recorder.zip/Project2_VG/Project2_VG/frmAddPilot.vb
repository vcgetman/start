﻿Public Class frmAddPilot
    Private Sub frmPilots_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim strSelect As String = ""
        Dim cmdSelect As OleDb.OleDbCommand ' this will be used for our Select statement
        Dim drSourceTable As OleDb.OleDbDataReader ' this will be where our data is retrieved to
        Dim dtPilots As DataTable = New DataTable ' this is the table we will load from our reader


        Try


            ' open the DB this is in module
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                "The application will now close.",
                                Me.Text + " Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()

            End If


            ' Build the select statement to obtain Pilots
            strSelect = "SELECT intPilotID, strLastName FROM TPilots"

            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader
            dtPilots.Load(drSourceTable)

            'load the Last Name result set into the combobox.  For VB, we do this by binding the data to the combobox

            cboPilot.ValueMember = "intPilotID"
            cboPilot.DisplayMember = "strLastName"
            cboPilot.DataSource = dtPilots


            ' Clean up
            drSourceTable.Close()

            ' close the database connection
            CloseDatabaseConnection()

        Catch excError As Exception

            ' Log and display error message
            MessageBox.Show(excError.Message)

        End Try
    End Sub

    Private Sub cboPilot_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboPilot.SelectedIndexChanged
        Dim strSelect As String = ""
        Dim strLastName As String = ""
        Dim cmdSelect As OleDb.OleDbCommand ' this will be used for our Select statement
        Dim drSourceTable As OleDb.OleDbDataReader ' this will be where our data is retrieved to
        Dim dtPilots As DataTable = New DataTable ' this is the table we will load from our reader


        Try


            ' open the database this is in module
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()

            End If

            ' Build the select statement using PK from name selected
            strSelect = (" SELECT TP.intPilotID, TF.strFlightNumber, TF.dtmFlightDate, TF.dtmTimeofDeparture, TF.dtmTimeOfLanding " +
                        " FROM TPilots as TP Join TPilotFlights as TPF " +
                        " On TP.intPilotID = TPF.intPilotID " +
                        " Join TFlights as TF " +
                        " On TPF.intFlightID = TF.intFlightID " +
                        " Where TP.intPilotID = " & cboPilot.SelectedValue)

            'MessageBox.Show(strSelect)

            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader



            lstPilots.Items.Clear()


            ' populate the text boxes with the data
            lstPilots.Items.Add("=============================")


            While drSourceTable.Read()

                lstPilots.Items.Add("  ")

                lstPilots.Items.Add("Flight Number: " & vbTab & drSourceTable("strFlightNumber"))
                lstPilots.Items.Add("Flight Date : " & vbTab & drSourceTable("dtmFlightDate"))
                lstPilots.Items.Add("Departure Time: " & vbTab & drSourceTable("dtmTimeofDeparture"))
                lstPilots.Items.Add("Arrival Time : " & vbTab & drSourceTable("dtmTimeOfLanding"))

                lstPilots.Items.Add("  ")
                lstPilots.Items.Add("=============================")

            End While


            ' close the database connection
            CloseDatabaseConnection()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try


        'End While



    End Sub
End Class