﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAddAttendant
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnSubmit = New System.Windows.Forms.Button()
        Me.gpbAdd = New System.Windows.Forms.GroupBox()
        Me.txtDateHire = New System.Windows.Forms.TextBox()
        Me.lbl6 = New System.Windows.Forms.Label()
        Me.lbl4 = New System.Windows.Forms.Label()
        Me.lbl3 = New System.Windows.Forms.Label()
        Me.lbl2 = New System.Windows.Forms.Label()
        Me.lbl1 = New System.Windows.Forms.Label()
        Me.txtDateTerm = New System.Windows.Forms.TextBox()
        Me.txtEmployeeID = New System.Windows.Forms.TextBox()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.gpbAdd.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(227, 317)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(1)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(112, 32)
        Me.btnExit.TabIndex = 14
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'btnSubmit
        '
        Me.btnSubmit.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnSubmit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnSubmit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSubmit.Location = New System.Drawing.Point(43, 317)
        Me.btnSubmit.Margin = New System.Windows.Forms.Padding(1)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(112, 32)
        Me.btnSubmit.TabIndex = 13
        Me.btnSubmit.Text = "Submit"
        Me.btnSubmit.UseVisualStyleBackColor = False
        '
        'gpbAdd
        '
        Me.gpbAdd.Controls.Add(Me.txtDateHire)
        Me.gpbAdd.Controls.Add(Me.lbl6)
        Me.gpbAdd.Controls.Add(Me.lbl4)
        Me.gpbAdd.Controls.Add(Me.lbl3)
        Me.gpbAdd.Controls.Add(Me.lbl2)
        Me.gpbAdd.Controls.Add(Me.lbl1)
        Me.gpbAdd.Controls.Add(Me.txtDateTerm)
        Me.gpbAdd.Controls.Add(Me.txtEmployeeID)
        Me.gpbAdd.Controls.Add(Me.txtLastName)
        Me.gpbAdd.Controls.Add(Me.txtFirstName)
        Me.gpbAdd.Location = New System.Drawing.Point(43, 37)
        Me.gpbAdd.Margin = New System.Windows.Forms.Padding(1)
        Me.gpbAdd.Name = "gpbAdd"
        Me.gpbAdd.Padding = New System.Windows.Forms.Padding(1)
        Me.gpbAdd.Size = New System.Drawing.Size(296, 261)
        Me.gpbAdd.TabIndex = 12
        Me.gpbAdd.TabStop = False
        Me.gpbAdd.Text = "Submit Attendant"
        '
        'txtDateHire
        '
        Me.txtDateHire.Location = New System.Drawing.Point(137, 157)
        Me.txtDateHire.Name = "txtDateHire"
        Me.txtDateHire.Size = New System.Drawing.Size(100, 20)
        Me.txtDateHire.TabIndex = 36
        '
        'lbl6
        '
        Me.lbl6.AutoSize = True
        Me.lbl6.Location = New System.Drawing.Point(21, 199)
        Me.lbl6.Name = "lbl6"
        Me.lbl6.Size = New System.Drawing.Size(100, 13)
        Me.lbl6.TabIndex = 32
        Me.lbl6.Text = "Date of Termination"
        '
        'lbl4
        '
        Me.lbl4.AutoSize = True
        Me.lbl4.Location = New System.Drawing.Point(21, 160)
        Me.lbl4.Name = "lbl4"
        Me.lbl4.Size = New System.Drawing.Size(64, 13)
        Me.lbl4.TabIndex = 30
        Me.lbl4.Text = "Date of Hire"
        '
        'lbl3
        '
        Me.lbl3.AutoSize = True
        Me.lbl3.Location = New System.Drawing.Point(21, 120)
        Me.lbl3.Name = "lbl3"
        Me.lbl3.Size = New System.Drawing.Size(64, 13)
        Me.lbl3.TabIndex = 29
        Me.lbl3.Text = "EmployeeID"
        '
        'lbl2
        '
        Me.lbl2.AutoSize = True
        Me.lbl2.Location = New System.Drawing.Point(21, 78)
        Me.lbl2.Name = "lbl2"
        Me.lbl2.Size = New System.Drawing.Size(61, 13)
        Me.lbl2.TabIndex = 28
        Me.lbl2.Text = "Last Name:"
        '
        'lbl1
        '
        Me.lbl1.AutoSize = True
        Me.lbl1.Location = New System.Drawing.Point(21, 35)
        Me.lbl1.Name = "lbl1"
        Me.lbl1.Size = New System.Drawing.Size(60, 13)
        Me.lbl1.TabIndex = 27
        Me.lbl1.Text = "First Name:"
        '
        'txtDateTerm
        '
        Me.txtDateTerm.Location = New System.Drawing.Point(137, 199)
        Me.txtDateTerm.Name = "txtDateTerm"
        Me.txtDateTerm.Size = New System.Drawing.Size(100, 20)
        Me.txtDateTerm.TabIndex = 21
        '
        'txtEmployeeID
        '
        Me.txtEmployeeID.Location = New System.Drawing.Point(137, 113)
        Me.txtEmployeeID.Name = "txtEmployeeID"
        Me.txtEmployeeID.Size = New System.Drawing.Size(100, 20)
        Me.txtEmployeeID.TabIndex = 20
        '
        'txtLastName
        '
        Me.txtLastName.Location = New System.Drawing.Point(137, 71)
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(100, 20)
        Me.txtLastName.TabIndex = 19
        '
        'txtFirstName
        '
        Me.txtFirstName.Location = New System.Drawing.Point(137, 29)
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(100, 20)
        Me.txtFirstName.TabIndex = 18
        '
        'frmAddAttendant
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(395, 452)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnSubmit)
        Me.Controls.Add(Me.gpbAdd)
        Me.Name = "frmAddAttendant"
        Me.Text = "frmAddAttendant"
        Me.gpbAdd.ResumeLayout(False)
        Me.gpbAdd.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnExit As Button
    Friend WithEvents btnSubmit As Button
    Friend WithEvents gpbAdd As GroupBox
    Friend WithEvents txtDateHire As TextBox
    Friend WithEvents lbl6 As Label
    Friend WithEvents lbl4 As Label
    Friend WithEvents lbl3 As Label
    Friend WithEvents lbl2 As Label
    Friend WithEvents lbl1 As Label
    Friend WithEvents txtDateTerm As TextBox
    Friend WithEvents txtEmployeeID As TextBox
    Friend WithEvents txtLastName As TextBox
    Friend WithEvents txtFirstName As TextBox
End Class
